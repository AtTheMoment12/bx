/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2018-2020 dwc
 */

#include <sys/queue.h>
#include <stdio.h>
#include <errno.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <stdarg.h>
#include <inttypes.h>
#include <netinet/in.h>
#include <rte_byteorder.h>
#include <rte_common.h>
#include <rte_cycles.h>

#include <rte_interrupts.h>
#include <rte_log.h>
#include <rte_debug.h>
#include <rte_pci.h>
#include <rte_bus_pci.h>
#include <rte_branch_prediction.h>
#include <rte_memory.h>
#include <rte_eal.h>
#include <rte_alarm.h>
#include <rte_ether.h>
#include <rte_ethdev_driver.h>
#include <rte_ethdev_pci.h>
#include <rte_malloc.h>
#include <rte_random.h>
#include <rte_dev.h>
#include <rte_hash_crc.h>
#ifdef RTE_LIBRTE_SECURITY
#include <rte_security_driver.h>
#endif

//#include "ixgbe_logs.h"
//#include "base/ixgbe_api.h"
//#include "base/ixgbe_vf.h"
//#include "base/ixgbe_common.h"
//#include "base/ixgbe_phy.h"
#include "dwc_ethdev.h"
#include "dwc_rxtx.h"
#include "base/dwc_type.h"
#include "dwc_regs.h"


/*Default value of Max Rx Queue*/
#define DWC_MAX_RX_QUEUE_NUM 128

#define DWC_VMDQ_NUM_UC_MAC         4096 /* Maximum nb. of UC MAC addr. */

#define DWC_MAX_RING_DESC           4096 /* replicate define from rxtx */

/*
 *  Default values for RX/TX configuration
 */
#define DWC_DEFAULT_RX_FREE_THRESH  32
#define DWC_DEFAULT_RX_PTHRESH      8
#define DWC_DEFAULT_RX_HTHRESH      8
#define DWC_DEFAULT_RX_WTHRESH      0

#define DWC_DEFAULT_TX_FREE_THRESH  32
#define DWC_DEFAULT_TX_PTHRESH      32
#define DWC_DEFAULT_TX_HTHRESH      0
#define DWC_DEFAULT_TX_WTHRESH      0
#define DWC_DEFAULT_TX_RSBIT_THRESH 32

/* Additional timesync values. */
#define NSEC_PER_SEC             1000000000L

#define DWC_VTEICR_MASK                      0x07


static int eth_dwc_dev_init(struct rte_eth_dev *eth_dev, void *init_params);
static int eth_dwc_dev_uninit(struct rte_eth_dev *eth_dev);
static int dwc_fdir_filter_init(struct rte_eth_dev *eth_dev);
static int dwc_l2_tn_filter_init(struct rte_eth_dev *eth_dev);
static int  dwc_dev_configure(struct rte_eth_dev *dev);
static int  dwc_dev_start(struct rte_eth_dev *dev);
static void dwc_dev_stop(struct rte_eth_dev *dev);
static int  dwc_dev_set_link_up(struct rte_eth_dev *dev);
static int  dwc_dev_set_link_down(struct rte_eth_dev *dev);
static void dwc_dev_close(struct rte_eth_dev *dev);
static int  dwc_dev_reset(struct rte_eth_dev *dev);
static void dwc_dev_promiscuous_enable(struct rte_eth_dev *dev);
static void dwc_dev_promiscuous_disable(struct rte_eth_dev *dev);
static void dwc_dev_allmulticast_enable(struct rte_eth_dev *dev);
static void dwc_dev_allmulticast_disable(struct rte_eth_dev *dev);
static int dwc_dev_link_update(struct rte_eth_dev *dev,
				int wait_to_complete);
static int dwc_dev_stats_get(struct rte_eth_dev *dev,
				struct rte_eth_stats *stats);
static int dwc_dev_xstats_get(struct rte_eth_dev *dev,
				struct rte_eth_xstat *xstats, unsigned n);
static int
dwc_dev_xstats_get_by_id(struct rte_eth_dev *dev, const uint64_t *ids,
		uint64_t *values, unsigned int n);
static void dwc_dev_stats_reset(struct rte_eth_dev *dev);
static void dwc_dev_xstats_reset(struct rte_eth_dev *dev);
static int dwc_dev_xstats_get_names(struct rte_eth_dev *dev,
	struct rte_eth_xstat_name *xstats_names,
	unsigned int size);
static int dwc_dev_xstats_get_names_by_id(
	struct rte_eth_dev *dev,
	struct rte_eth_xstat_name *xstats_names,
	const uint64_t *ids,
	unsigned int limit);
static int dwc_dev_queue_stats_mapping_set(struct rte_eth_dev *eth_dev,
					     uint16_t queue_id,
					     uint8_t stat_idx,
					     uint8_t is_rx);
static int dwc_fw_version_get(struct rte_eth_dev *dev, char *fw_version,
				 size_t fw_size);
static void dwc_dev_info_get(struct rte_eth_dev *dev,
			       struct rte_eth_dev_info *dev_info);
static const uint32_t *dwc_dev_supported_ptypes_get(struct rte_eth_dev *dev);
static int dwc_dev_mtu_set(struct rte_eth_dev *dev, uint16_t mtu);

static int dwc_vlan_offload_config(struct rte_eth_dev *dev, int mask);
static void dwc_dev_link_status_print(struct rte_eth_dev *dev);
static int dwc_dev_lsc_interrupt_setup(struct rte_eth_dev *dev, uint8_t on);
static int dwc_dev_macsec_interrupt_setup(struct rte_eth_dev *dev);
static int dwc_dev_rxq_interrupt_setup(struct rte_eth_dev *dev);
static int dwc_dev_interrupt_get_status(struct rte_eth_dev *dev);
static int dwc_dev_interrupt_action(struct rte_eth_dev *dev);
static void dwc_dev_interrupt_handler(void *param);
static void dwc_dev_setup_link_alarm_handler(void *param);

static bool is_device_supported(struct rte_eth_dev *dev,
				struct rte_pci_driver *drv);

/* For Virtual Function support */
static int eth_dwcvf_dev_init(struct rte_eth_dev *eth_dev);
static int eth_dwcvf_dev_uninit(struct rte_eth_dev *eth_dev);
static int  dwcvf_dev_configure(struct rte_eth_dev *dev);
static int  dwcvf_dev_start(struct rte_eth_dev *dev);
static int dwcvf_dev_link_update(struct rte_eth_dev *dev,
				   int wait_to_complete);
static void dwcvf_dev_stop(struct rte_eth_dev *dev);
static void dwcvf_dev_close(struct rte_eth_dev *dev);
static void dwcvf_intr_disable(struct rte_eth_dev *dev);
static void dwcvf_intr_enable(struct rte_eth_dev *dev);
static void dwcvf_configure_msix(struct rte_eth_dev *dev);

/* For Eth VMDQ APIs support */
static void dwc_configure_msix(struct rte_eth_dev *dev);

static void dwcvf_remove_mac_addr(struct rte_eth_dev *dev, uint32_t index);

static void dwcvf_dev_interrupt_handler(void *param);

static int dwc_filter_restore(struct rte_eth_dev *dev);
static void dwc_l2_tunnel_conf(struct rte_eth_dev *dev);

int dwc_logtype_init;
int dwc_logtype_driver;

/*
 * The set of PCI devices this driver supports
 */
static const struct rte_pci_id pci_id_dwc_map[] = {
	{ RTE_PCI_DEVICE(DWC_VENDOR_ID, DWC_DEV_ID_1) },
	{ RTE_PCI_DEVICE(DWC_VENDOR_ID, DWC_DEV_ID_2) },
	{ RTE_PCI_DEVICE(DWC_VENDOR_ID, DWC_DEV_ID_3) },
	{ .vendor_id = 0, /* sentinel */ },
};

/*
 * The set of PCI devices this driver supports (for VF)
 */
static const struct rte_pci_id pci_id_dwcvf_map[] = {
	{ RTE_PCI_DEVICE(DWC_VENDOR_ID, DWC_DEV_ID_1) },
	{ RTE_PCI_DEVICE(DWC_VENDOR_ID, DWC_DEV_ID_2) },
	{ RTE_PCI_DEVICE(DWC_VENDOR_ID, DWC_DEV_ID_3) },
	{ .vendor_id = 0, /* sentinel */ },
};

static const struct rte_eth_desc_lim rx_desc_lim = {
	.nb_max = DWC_MAX_RING_DESC,
	.nb_min = DWC_MIN_RING_DESC,
	.nb_align = DWC_RXD_ALIGN,
};

static const struct rte_eth_desc_lim tx_desc_lim = {
	.nb_max = DWC_MAX_RING_DESC,
	.nb_min = DWC_MIN_RING_DESC,
	.nb_align = DWC_TXD_ALIGN,
	.nb_seg_max = DWC_TX_MAX_SEG,
	.nb_mtu_seg_max = DWC_TX_MAX_SEG,
};

static const struct eth_dev_ops dwc_eth_dev_ops = {
	.dev_configure        = dwc_dev_configure,
	.dev_start            = dwc_dev_start,
	.dev_stop             = dwc_dev_stop,
	.dev_set_link_up    = dwc_dev_set_link_up,
	.dev_set_link_down  = dwc_dev_set_link_down,
	.dev_close            = dwc_dev_close,
	.dev_reset	      = dwc_dev_reset,
	.promiscuous_enable   = dwc_dev_promiscuous_enable,
	.promiscuous_disable  = dwc_dev_promiscuous_disable,
	.allmulticast_enable  = dwc_dev_allmulticast_enable,
	.allmulticast_disable = dwc_dev_allmulticast_disable,
	.link_update          = dwc_dev_link_update,
	.stats_get            = dwc_dev_stats_get,
	.stats_reset          = dwc_dev_stats_reset,
	.queue_stats_mapping_set = dwc_dev_queue_stats_mapping_set,
	.dev_infos_get        = dwc_dev_info_get,
	.dev_supported_ptypes_get = dwc_dev_supported_ptypes_get,
	.mtu_set              = dwc_dev_mtu_set,

	.rx_queue_setup       = dwc_dev_rx_queue_setup,
	.tx_queue_setup       = dwc_dev_tx_queue_setup,
	
#if 0 //add by zs

	.xstats_get           = dwc_dev_xstats_get,
	.xstats_get_by_id     = dwc_dev_xstats_get_by_id,
	.xstats_reset         = dwc_dev_xstats_reset,
	.xstats_get_names     = dwc_dev_xstats_get_names,
	.xstats_get_names_by_id = dwc_dev_xstats_get_names_by_id,
	.fw_version_get       = dwc_fw_version_get,
	
	.vlan_filter_set      = ixgbe_vlan_filter_set,
	.vlan_tpid_set        = ixgbe_vlan_tpid_set,
	.vlan_offload_set     = ixgbe_vlan_offload_set,
	.vlan_strip_queue_set = ixgbe_vlan_strip_queue_set,
	.rx_queue_start	      = ixgbe_dev_rx_queue_start,
	.rx_queue_stop        = ixgbe_dev_rx_queue_stop,
	.tx_queue_start	      = ixgbe_dev_tx_queue_start,
	.tx_queue_stop        = ixgbe_dev_tx_queue_stop,
	.rx_queue_intr_enable = ixgbe_dev_rx_queue_intr_enable,
	.rx_queue_intr_disable = ixgbe_dev_rx_queue_intr_disable,
	.rx_queue_release     = ixgbe_dev_rx_queue_release,
	.rx_queue_count       = ixgbe_dev_rx_queue_count,
	.rx_descriptor_done   = ixgbe_dev_rx_descriptor_done,
	.rx_descriptor_status = ixgbe_dev_rx_descriptor_status,
	.tx_descriptor_status = ixgbe_dev_tx_descriptor_status,
	.tx_queue_release     = ixgbe_dev_tx_queue_release,
	.dev_led_on           = ixgbe_dev_led_on,
	.dev_led_off          = ixgbe_dev_led_off,
	.flow_ctrl_get        = ixgbe_flow_ctrl_get,
	.flow_ctrl_set        = ixgbe_flow_ctrl_set,
	.priority_flow_ctrl_set = ixgbe_priority_flow_ctrl_set,
	.mac_addr_add         = ixgbe_add_rar,
	.mac_addr_remove      = ixgbe_remove_rar,
	.mac_addr_set         = ixgbe_set_default_mac_addr,
	.uc_hash_table_set    = ixgbe_uc_hash_table_set,
	.uc_all_hash_table_set  = ixgbe_uc_all_hash_table_set,
	.mirror_rule_set      = ixgbe_mirror_rule_set,
	.mirror_rule_reset    = ixgbe_mirror_rule_reset,
	.set_queue_rate_limit = ixgbe_set_queue_rate_limit,
	.reta_update          = ixgbe_dev_rss_reta_update,
	.reta_query           = ixgbe_dev_rss_reta_query,
	.rss_hash_update      = ixgbe_dev_rss_hash_update,
	.rss_hash_conf_get    = ixgbe_dev_rss_hash_conf_get,
	.filter_ctrl          = ixgbe_dev_filter_ctrl,
	.set_mc_addr_list     = ixgbe_dev_set_mc_addr_list,
	.rxq_info_get         = ixgbe_rxq_info_get,
	.txq_info_get         = ixgbe_txq_info_get,
	.timesync_enable      = ixgbe_timesync_enable,
	.timesync_disable     = ixgbe_timesync_disable,
	.timesync_read_rx_timestamp = ixgbe_timesync_read_rx_timestamp,
	.timesync_read_tx_timestamp = ixgbe_timesync_read_tx_timestamp,
	.get_reg              = ixgbe_get_regs,
	.get_eeprom_length    = ixgbe_get_eeprom_length,
	.get_eeprom           = ixgbe_get_eeprom,
	.set_eeprom           = ixgbe_set_eeprom,
	.get_module_info      = ixgbe_get_module_info,
	.get_module_eeprom    = ixgbe_get_module_eeprom,
	.get_dcb_info         = ixgbe_dev_get_dcb_info,
	.timesync_adjust_time = ixgbe_timesync_adjust_time,
	.timesync_read_time   = ixgbe_timesync_read_time,
	.timesync_write_time  = ixgbe_timesync_write_time,
	.l2_tunnel_eth_type_conf = ixgbe_dev_l2_tunnel_eth_type_conf,
	.l2_tunnel_offload_set   = ixgbe_dev_l2_tunnel_offload_set,
	.udp_tunnel_port_add  = ixgbe_dev_udp_tunnel_port_add,
	.udp_tunnel_port_del  = ixgbe_dev_udp_tunnel_port_del,
	.tm_ops_get           = ixgbe_tm_ops_get,

#endif //add by zs

};

/*
 * dev_ops for virtual function, bare necessities for basic vf
 * operation have been implemented
 */
static const struct eth_dev_ops dwcvf_eth_dev_ops = {
	.dev_configure        = dwcvf_dev_configure,
	.dev_start            = dwcvf_dev_start,
	.dev_stop             = dwcvf_dev_stop,
	.link_update          = dwcvf_dev_link_update,
	
#if 0	//add by zs	

	.stats_get            = ixgbevf_dev_stats_get,
	.xstats_get           = ixgbevf_dev_xstats_get,
	.stats_reset          = ixgbevf_dev_stats_reset,
	.xstats_reset         = ixgbevf_dev_stats_reset,
	.xstats_get_names     = ixgbevf_dev_xstats_get_names,
	.dev_close            = dwcvf_dev_close,
	.dev_reset	      = ixgbevf_dev_reset,
	.allmulticast_enable  = ixgbevf_dev_allmulticast_enable,
	.allmulticast_disable = ixgbevf_dev_allmulticast_disable,
	.dev_supported_ptypes_get = dwc_dev_supported_ptypes_get,

	.mtu_set              = ixgbevf_dev_set_mtu,
	.vlan_filter_set      = ixgbevf_vlan_filter_set,
	.vlan_strip_queue_set = ixgbevf_vlan_strip_queue_set,
	.vlan_offload_set     = ixgbevf_vlan_offload_set,
#endif	//add by zs
	
	.dev_infos_get        = dwcvf_dev_info_get,
	.rx_queue_setup       = dwc_dev_rx_queue_setup,
	.rx_queue_release     = dwc_dev_rx_queue_release,
	
	.tx_queue_setup       = dwc_dev_tx_queue_setup,
	.tx_queue_release     = dwc_dev_tx_queue_release,

#if 0
	.rx_descriptor_done   = ixgbe_dev_rx_descriptor_done,
	.rx_descriptor_status = ixgbe_dev_rx_descriptor_status,
	.tx_descriptor_status = ixgbe_dev_tx_descriptor_status,
	.rx_queue_intr_enable = ixgbevf_dev_rx_queue_intr_enable,
	.rx_queue_intr_disable = ixgbevf_dev_rx_queue_intr_disable,
	.mac_addr_add         = ixgbevf_add_mac_addr,
	.mac_addr_remove      = dwcvf_remove_mac_addr,
	.set_mc_addr_list     = ixgbe_dev_set_mc_addr_list,
	.rxq_info_get         = ixgbe_rxq_info_get,
	.txq_info_get         = ixgbe_txq_info_get,
	.mac_addr_set         = ixgbevf_set_default_mac_addr,
	.get_reg              = ixgbevf_get_regs,
	.reta_update          = ixgbe_dev_rss_reta_update,
	.reta_query           = ixgbe_dev_rss_reta_query,
	.rss_hash_update      = ixgbe_dev_rss_hash_update,
	.rss_hash_conf_get    = ixgbe_dev_rss_hash_conf_get,
	
#endif	//add by zs
	
};

/* store statistics names and its offset in stats structure */
struct rte_dwc_xstats_name_off {
	char name[RTE_ETH_XSTATS_NAME_SIZE];
	unsigned offset;
};

static const struct rte_dwc_xstats_name_off rte_dwc_stats_strings[] = {
	{"rx_crc_errors", offsetof(struct dwc_hw_stats, crcerrs)},
	{"rx_illegal_byte_errors", offsetof(struct dwc_hw_stats, illerrc)},
	{"rx_error_bytes", offsetof(struct dwc_hw_stats, errbc)},
	{"mac_local_errors", offsetof(struct dwc_hw_stats, mlfc)},
	{"mac_remote_errors", offsetof(struct dwc_hw_stats, mrfc)},
	{"rx_length_errors", offsetof(struct dwc_hw_stats, rlec)},
	{"tx_xon_packets", offsetof(struct dwc_hw_stats, lxontxc)},
	{"rx_xon_packets", offsetof(struct dwc_hw_stats, lxonrxc)},
	{"tx_xoff_packets", offsetof(struct dwc_hw_stats, lxofftxc)},
	{"rx_xoff_packets", offsetof(struct dwc_hw_stats, lxoffrxc)},
	{"rx_size_64_packets", offsetof(struct dwc_hw_stats, prc64)},
	{"rx_size_65_to_127_packets", offsetof(struct dwc_hw_stats, prc127)},
	{"rx_size_128_to_255_packets", offsetof(struct dwc_hw_stats, prc255)},
	{"rx_size_256_to_511_packets", offsetof(struct dwc_hw_stats, prc511)},
	{"rx_size_512_to_1023_packets", offsetof(struct dwc_hw_stats,
		prc1023)},
	{"rx_size_1024_to_max_packets", offsetof(struct dwc_hw_stats,
		prc1522)},
	{"rx_broadcast_packets", offsetof(struct dwc_hw_stats, bprc)},
	{"rx_multicast_packets", offsetof(struct dwc_hw_stats, mprc)},
	{"rx_fragment_errors", offsetof(struct dwc_hw_stats, rfc)},
	{"rx_undersize_errors", offsetof(struct dwc_hw_stats, ruc)},
	{"rx_oversize_errors", offsetof(struct dwc_hw_stats, roc)},
	{"rx_jabber_errors", offsetof(struct dwc_hw_stats, rjc)},
	{"rx_management_packets", offsetof(struct dwc_hw_stats, mngprc)},
	{"rx_management_dropped", offsetof(struct dwc_hw_stats, mngpdc)},
	{"tx_management_packets", offsetof(struct dwc_hw_stats, mngptc)},
	{"rx_total_packets", offsetof(struct dwc_hw_stats, tpr)},
	{"rx_total_bytes", offsetof(struct dwc_hw_stats, tor)},
	{"tx_total_packets", offsetof(struct dwc_hw_stats, tpt)},
	{"tx_size_64_packets", offsetof(struct dwc_hw_stats, ptc64)},
	{"tx_size_65_to_127_packets", offsetof(struct dwc_hw_stats, ptc127)},
	{"tx_size_128_to_255_packets", offsetof(struct dwc_hw_stats, ptc255)},
	{"tx_size_256_to_511_packets", offsetof(struct dwc_hw_stats, ptc511)},
	{"tx_size_512_to_1023_packets", offsetof(struct dwc_hw_stats,
		ptc1023)},
	{"tx_size_1024_to_max_packets", offsetof(struct dwc_hw_stats,
		ptc1522)},
	{"tx_multicast_packets", offsetof(struct dwc_hw_stats, mptc)},
	{"tx_broadcast_packets", offsetof(struct dwc_hw_stats, bptc)},
	{"rx_mac_short_packet_dropped", offsetof(struct dwc_hw_stats, mspdc)},
	{"rx_l3_l4_xsum_error", offsetof(struct dwc_hw_stats, xec)},

	{"flow_director_added_filters", offsetof(struct dwc_hw_stats,
		fdirustat_add)},
	{"flow_director_removed_filters", offsetof(struct dwc_hw_stats,
		fdirustat_remove)},
	{"flow_director_filter_add_errors", offsetof(struct dwc_hw_stats,
		fdirfstat_fadd)},
	{"flow_director_filter_remove_errors", offsetof(struct dwc_hw_stats,
		fdirfstat_fremove)},
	{"flow_director_matched_filters", offsetof(struct dwc_hw_stats,
		fdirmatch)},
	{"flow_director_missed_filters", offsetof(struct dwc_hw_stats,
		fdirmiss)},

	{"rx_fcoe_crc_errors", offsetof(struct dwc_hw_stats, fccrc)},
	{"rx_fcoe_dropped", offsetof(struct dwc_hw_stats, fcoerpdc)},
	{"rx_fcoe_mbuf_allocation_errors", offsetof(struct dwc_hw_stats,
		fclast)},
	{"rx_fcoe_packets", offsetof(struct dwc_hw_stats, fcoeprc)},
	{"tx_fcoe_packets", offsetof(struct dwc_hw_stats, fcoeptc)},
	{"rx_fcoe_bytes", offsetof(struct dwc_hw_stats, fcoedwrc)},
	{"tx_fcoe_bytes", offsetof(struct dwc_hw_stats, fcoedwtc)},
	{"rx_fcoe_no_direct_data_placement", offsetof(struct dwc_hw_stats,
		fcoe_noddp)},
	{"rx_fcoe_no_direct_data_placement_ext_buff",
		offsetof(struct dwc_hw_stats, fcoe_noddp_ext_buff)},

	{"tx_flow_control_xon_packets", offsetof(struct dwc_hw_stats,
		lxontxc)},
	{"rx_flow_control_xon_packets", offsetof(struct dwc_hw_stats,
		lxonrxc)},
	{"tx_flow_control_xoff_packets", offsetof(struct dwc_hw_stats,
		lxofftxc)},
	{"rx_flow_control_xoff_packets", offsetof(struct dwc_hw_stats,
		lxoffrxc)},
	{"rx_total_missed_packets", offsetof(struct dwc_hw_stats, mpctotal)},
};

#define DWC_NB_HW_STATS (sizeof(rte_dwc_stats_strings) / \
			   sizeof(rte_dwc_stats_strings[0]))

/* MACsec statistics */
static const struct rte_dwc_xstats_name_off rte_dwc_macsec_strings[] = {
	{"out_pkts_untagged", offsetof(struct dwc_macsec_stats,
		out_pkts_untagged)},
	{"out_pkts_encrypted", offsetof(struct dwc_macsec_stats,
		out_pkts_encrypted)},
	{"out_pkts_protected", offsetof(struct dwc_macsec_stats,
		out_pkts_protected)},
	{"out_octets_encrypted", offsetof(struct dwc_macsec_stats,
		out_octets_encrypted)},
	{"out_octets_protected", offsetof(struct dwc_macsec_stats,
		out_octets_protected)},
	{"in_pkts_untagged", offsetof(struct dwc_macsec_stats,
		in_pkts_untagged)},
	{"in_pkts_badtag", offsetof(struct dwc_macsec_stats,
		in_pkts_badtag)},
	{"in_pkts_nosci", offsetof(struct dwc_macsec_stats,
		in_pkts_nosci)},
	{"in_pkts_unknownsci", offsetof(struct dwc_macsec_stats,
		in_pkts_unknownsci)},
	{"in_octets_decrypted", offsetof(struct dwc_macsec_stats,
		in_octets_decrypted)},
	{"in_octets_validated", offsetof(struct dwc_macsec_stats,
		in_octets_validated)},
	{"in_pkts_unchecked", offsetof(struct dwc_macsec_stats,
		in_pkts_unchecked)},
	{"in_pkts_delayed", offsetof(struct dwc_macsec_stats,
		in_pkts_delayed)},
	{"in_pkts_late", offsetof(struct dwc_macsec_stats,
		in_pkts_late)},
	{"in_pkts_ok", offsetof(struct dwc_macsec_stats,
		in_pkts_ok)},
	{"in_pkts_invalid", offsetof(struct dwc_macsec_stats,
		in_pkts_invalid)},
	{"in_pkts_notvalid", offsetof(struct dwc_macsec_stats,
		in_pkts_notvalid)},
	{"in_pkts_unusedsa", offsetof(struct dwc_macsec_stats,
		in_pkts_unusedsa)},
	{"in_pkts_notusingsa", offsetof(struct dwc_macsec_stats,
		in_pkts_notusingsa)},
};

#define DWC_NB_MACSEC_STATS (sizeof(rte_dwc_macsec_strings) / \
			   sizeof(rte_dwc_macsec_strings[0]))

/* Per-queue statistics */
static const struct rte_dwc_xstats_name_off rte_dwc_rxq_strings[] = {
	{"mbuf_allocation_errors", offsetof(struct dwc_hw_stats, rnbc)},
	{"dropped", offsetof(struct dwc_hw_stats, mpc)},
	{"xon_packets", offsetof(struct dwc_hw_stats, pxonrxc)},
	{"xoff_packets", offsetof(struct dwc_hw_stats, pxoffrxc)},
};

#define DWC_NB_RXQ_PRIO_STATS (sizeof(rte_dwc_rxq_strings) / \
			   sizeof(rte_dwc_rxq_strings[0]))
#define DWC_NB_RXQ_PRIO_VALUES 8

static const struct rte_dwc_xstats_name_off rte_dwc_txq_strings[] = {
	{"xon_packets", offsetof(struct dwc_hw_stats, pxontxc)},
	{"xoff_packets", offsetof(struct dwc_hw_stats, pxofftxc)},
	{"xon_to_xoff_packets", offsetof(struct dwc_hw_stats,
		pxon2offc)},
};

#define DWC_NB_TXQ_PRIO_STATS (sizeof(rte_dwc_txq_strings) / \
			   sizeof(rte_dwc_txq_strings[0]))
#define DWC_NB_TXQ_PRIO_VALUES 8

static const struct rte_dwc_xstats_name_off rte_ixgbevf_stats_strings[] = {
	{"rx_multicast_packets", offsetof(struct ixgbevf_hw_stats, vfmprc)},
};


/*
 * This function is the same as dwc_is_sfp() in base/ixgbe.h.
 */
static inline int
dwc_is_sfp(struct dwc_hw *hw)
{
	switch (hw->phy.type) {
	case dwc_phy_sfp_avago:
	case dwc_phy_sfp_ftl:
	case dwc_phy_sfp_unknown:
	case dwc_phy_sfp_passive_tyco:
	case dwc_phy_sfp_passive_unknown:
		return 1;
	default:
		return 0;
	}
}

static inline int32_t
//dwc_pf_reset_hw(struct dwc_hw *hw)
dwc_pf_reset_hw(struct mac_pdata *pdata)
{

	int ret;
	ret = mac_restart_dev(pdata);
	return ret;

#if 0 //add by zs

	uint32_t ctrl_ext;
	int32_t status;

	status = dwc_reset_hw(hw);

	ctrl_ext = DWC_READ_REG(hw, DWC_CTRL_EXT);
	/* Set PF Reset Done bit so PF/VF Mail Ops can work */
	ctrl_ext |= IXGBE_CTRL_EXT_PFRSTD;
	DWC_WRITE_REG(hw, IXGBE_CTRL_EXT, ctrl_ext);
	DWC_WRITE_FLUSH(hw);

	if (status == DWC_ERR_SFP_NOT_PRESENT)
		status = DWC_SUCCESS;

	return status;
	
#endif //add by zs
}

static inline void
dwc_enable_intr(struct rte_eth_dev *dev)
{

#if 0 //add by zs
	struct dwc_interrupt *intr =
		DWC_DEV_PRIVATE_TO_INTR(dev->data->dev_private);
	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);

	DWC_WRITE_REG(hw, IXGBE_EIMS, intr->mask);
	DWC_WRITE_FLUSH(hw);
	
#endif //add by zs

	PMD_INIT_FUNC_TRACE();
	struct mac_pdata *pdata =
		DWC_DEV_PRIVATE_TO_PDATA(dev->data->dev_private);
	return dwc_call_func(pdata, pdata->hw_ops.enable_int, (pdata),
			       DWC_NOT_IMPLEMENTED);  //add by zs, 20200224
}

/*
 * This function is based on dwc_disable_intr() in base/ixgbe.h.
 */
static void
//dwc_disable_intr(struct dwc_hw *hw)
dwc_disable_intr(struct mac_pdata  *pdata)
{
	PMD_INIT_FUNC_TRACE();
	
#if 0	//add by zs, 20191224

	if (hw->mac.type == dwc_mac_1) {
		DWC_WRITE_REG(hw, IXGBE_EIMC, ~0);
	} else {
		DWC_WRITE_REG(hw, IXGBE_EIMC, 0xFFFF0000);
		DWC_WRITE_REG(hw, IXGBE_EIMC_EX(0), ~0);
		DWC_WRITE_REG(hw, IXGBE_EIMC_EX(1), ~0);
	}
	DWC_WRITE_FLUSH(hw);

#endif	//add by zs, 20191224

	return dwc_call_func(pdata, pdata->hw_ops.disable_int, (pdata),
			       DWC_NOT_IMPLEMENTED);  //add by zs, 20200224

}

/*
 * This function resets queue statistics mapping registers.
 * From Niantic datasheet, Initialization of Statistics section:
 * "...if software requires the queue counters, the RQSMR and TQSM registers
 * must be re-programmed following a device reset.
 */
static void
dwc_reset_qstat_mappings(struct dwc_hw *hw)
{
	uint32_t i;

#if 0	//add by zs,20191224

	for (i = 0; i != DWC_NB_STAT_MAPPING_REGS; i++) {
		DWC_WRITE_REG(hw, IXGBE_RQSMR(i), 0);
		DWC_WRITE_REG(hw, IXGBE_TQSM(i), 0);
	}

#endif	//add by zs,20191224
}


static int
dwc_dev_queue_stats_mapping_set(struct rte_eth_dev *eth_dev,
				  uint16_t queue_id,
				  uint8_t stat_idx,
				  uint8_t is_rx)
{
#define QSM_REG_NB_BITS_PER_QMAP_FIELD 8
#define NB_QMAP_FIELDS_PER_QSM_REG 4
#define QMAP_FIELD_RESERVED_BITS_MASK 0x0f

	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(eth_dev->data->dev_private);
	struct dwc_stat_mapping_registers *stat_mappings =
		DWC_DEV_PRIVATE_TO_STAT_MAPPINGS(eth_dev->data->dev_private);
	uint32_t qsmr_mask = 0;
	uint32_t clearing_mask = QMAP_FIELD_RESERVED_BITS_MASK;
	uint32_t q_map;
	uint8_t n, offset;

#if 0 //add by zs

	if ((hw->mac.type != ixgbe_mac_82599EB) &&
		(hw->mac.type != ixgbe_mac_X540) &&
		(hw->mac.type != ixgbe_mac_X550) &&
		(hw->mac.type != ixgbe_mac_X550EM_x) &&
		(hw->mac.type != ixgbe_mac_X550EM_a))
		return -ENOSYS;

	PMD_INIT_LOG(DEBUG, "Setting port %d, %s queue_id %d to stat index %d",
		     (int)(eth_dev->data->port_id), is_rx ? "RX" : "TX",
		     queue_id, stat_idx);

	n = (uint8_t)(queue_id / NB_QMAP_FIELDS_PER_QSM_REG);
	if (n >= IXGBE_NB_STAT_MAPPING_REGS) {
		PMD_INIT_LOG(ERR, "Nb of stat mapping registers exceeded");
		return -EIO;
	}
	offset = (uint8_t)(queue_id % NB_QMAP_FIELDS_PER_QSM_REG);

	/* Now clear any previous stat_idx set */
	clearing_mask <<= (QSM_REG_NB_BITS_PER_QMAP_FIELD * offset);
	if (!is_rx)
		stat_mappings->tqsm[n] &= ~clearing_mask;
	else
		stat_mappings->rqsmr[n] &= ~clearing_mask;

	q_map = (uint32_t)stat_idx;
	q_map &= QMAP_FIELD_RESERVED_BITS_MASK;
	qsmr_mask = q_map << (QSM_REG_NB_BITS_PER_QMAP_FIELD * offset);
	if (!is_rx)
		stat_mappings->tqsm[n] |= qsmr_mask;
	else
		stat_mappings->rqsmr[n] |= qsmr_mask;

	PMD_INIT_LOG(DEBUG, "Set port %d, %s queue_id %d to stat index %d",
		     (int)(eth_dev->data->port_id), is_rx ? "RX" : "TX",
		     queue_id, stat_idx);
	PMD_INIT_LOG(DEBUG, "%s[%d] = 0x%08x", is_rx ? "RQSMR" : "TQSM", n,
		     is_rx ? stat_mappings->rqsmr[n] : stat_mappings->tqsm[n]);

	/* Now write the mapping in the appropriate register */
	if (is_rx) {
		PMD_INIT_LOG(DEBUG, "Write 0x%x to RX IXGBE stat mapping reg:%d",
			     stat_mappings->rqsmr[n], n);
		DWC_WRITE_REG(hw, IXGBE_RQSMR(n), stat_mappings->rqsmr[n]);
	} else {
		PMD_INIT_LOG(DEBUG, "Write 0x%x to TX IXGBE stat mapping reg:%d",
			     stat_mappings->tqsm[n], n);
		DWC_WRITE_REG(hw, IXGBE_TQSM(n), stat_mappings->tqsm[n]);
	}

#endif //add by zs

	return 0;
}

/*
 * Ensure that all locks are released before first NVM or PHY access
 */
static void
dwc_swfw_lock_reset(struct dwc_hw *hw)
{
	uint16_t mask;

	/*
	 * Phy lock should not fail in this early stage. If this is the case,
	 * it is due to an improper exit of the application.
	 * So force the release of the faulty lock. Release of common lock
	 * is done automatically by swfw_sync function.
	 */
	mask = DWC_GSSR_PHY0_SM << hw->bus.func;
	if (dwc_acquire_swfw_semaphore(hw, mask) < 0) {
		PMD_DRV_LOG(DEBUG, "SWFW phy%d lock released", hw->bus.func);
	}
	dwc_release_swfw_semaphore(hw, mask);

	/*
	 * These ones are more tricky since they are common to all ports; but
	 * swfw_sync retries last long enough (1s) to be almost sure that if
	 * lock can not be taken it is due to an improper lock of the
	 * semaphore.
	 */
	mask = DWC_GSSR_EEP_SM | DWC_GSSR_MAC_CSR_SM | DWC_GSSR_SW_MNG_SM;
	if (dwc_acquire_swfw_semaphore(hw, mask) < 0) {
		PMD_DRV_LOG(DEBUG, "SWFW common locks released");
	}
	dwc_release_swfw_semaphore(hw, mask);
}

/*
 * This function is based on code in ixgbe_attach() in base/ixgbe.c.
 * It returns 0 on success.
 */
static int
eth_dwc_dev_init(struct rte_eth_dev *eth_dev, void *init_params __rte_unused)
{
	struct rte_pci_device *pci_dev = RTE_ETH_DEV_TO_PCI(eth_dev);
	struct rte_intr_handle *intr_handle = &pci_dev->intr_handle;
	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(eth_dev->data->dev_private);
	struct mac_pdata *pdata =
		DWC_DEV_PRIVATE_TO_PDATA(eth_dev->data->dev_private);

#if 0
	struct dwc_vfta *shadow_vfta =
		DWC_DEV_PRIVATE_TO_VFTA(eth_dev->data->dev_private);
	struct dwc_hwstrip *hwstrip =
		DWC_DEV_PRIVATE_TO_HWSTRIP_BITMAP(eth_dev->data->dev_private);
	struct ixgbe_dcb_config *dcb_config =
		IXGBE_DEV_PRIVATE_TO_DCB_CFG(eth_dev->data->dev_private);
	struct dwc_filter_info *filter_info =
		DWC_DEV_PRIVATE_TO_FILTER_INFO(eth_dev->data->dev_private);
	struct dwc_bw_conf *bw_conf =
		DWC_DEV_PRIVATE_TO_BW_CONF(eth_dev->data->dev_private);
#endif

	uint32_t ctrl_ext;
	uint16_t csum;
	int diag, i;

	PMD_INIT_FUNC_TRACE();

	eth_dev->dev_ops = &dwc_eth_dev_ops;
	eth_dev->rx_pkt_burst = &dwc_recv_pkts;
	eth_dev->tx_pkt_burst = &dwc_xmit_pkts;
	eth_dev->tx_pkt_prepare = &dwc_prep_pkts;

	/*
	 * For secondary processes, we don't initialise any further as primary
	 * has already done this work. Only check we don't need a different
	 * RX and TX function.
	 */
	if (rte_eal_process_type() != RTE_PROC_PRIMARY) {
		struct dwc_tx_queue *txq;
		/* TX queue function in primary, set by last queue initialized
		 * Tx queue may not initialized by primary process
		 */
		if (eth_dev->data->tx_queues) {
			txq = eth_dev->data->tx_queues[eth_dev->data->nb_tx_queues-1];
			dwc_set_tx_function(eth_dev, txq);
		} else {
			/* Use default TX function if we get here */
			PMD_INIT_LOG(NOTICE, "No TX queues configured yet. "
				     "Using default TX function.");
		}

		dwc_set_rx_function(eth_dev);

		return 0;
	}

	rte_eth_copy_pci_info(eth_dev, pci_dev);

	/* Vendor and Device ID need to be set before init of shared code */
	hw->device_id = pci_dev->id.device_id;
	hw->vendor_id = pci_dev->id.vendor_id;
	hw->hw_addr = (void *)pci_dev->mem_resource[0].addr;
	hw->allow_unsupported_sfp = 1;

	/* Initialize the shared code (base driver) */
#ifdef RTE_LIBRTE_DWC_BYPASS
//	diag = ixgbe_bypass_init_shared_code(hw);	//modify by zs
#else
	diag = dwc_init_shared_code(hw);
#endif 

	if (diag != DWC_SUCCESS) {
		PMD_INIT_LOG(ERR, "Shared code init failed: %d", diag);
		return -EIO;
	}

#if 0	//add by zs, 20200223
	if (hw->mac.ops.fw_recovery_mode && hw->mac.ops.fw_recovery_mode(hw)) {
		PMD_INIT_LOG(ERR, "\nERROR: "
			"Firmware recovery mode detected. Limiting functionality.\n"
			"Refer to the Intel(R) Ethernet Adapters and Devices "
			"User Guide for details on firmware recovery mode.");
		return -EIO;
	}
#endif

	/* pick up the PCI bus settings for reporting later */
	dwc_get_bus_info(hw);

	/* Unlock any pending hardware semaphore */
	dwc_swfw_lock_reset(hw);

#if 0 //add by zs

#ifdef RTE_LIBRTE_SECURITY
	/* Initialize security_ctx only for primary process*/
	if (ixgbe_ipsec_ctx_create(eth_dev))
		return -ENOMEM;
#endif

	/* Initialize DCB configuration*/
	memset(dcb_config, 0, sizeof(struct ixgbe_dcb_config));
	ixgbe_dcb_init(hw, dcb_config);
	/* Get Hardware Flow Control setting */
	hw->fc.requested_mode = ixgbe_fc_full;
	hw->fc.current_mode = ixgbe_fc_full;
	hw->fc.pause_time = IXGBE_FC_PAUSE;
	for (i = 0; i < IXGBE_DCB_MAX_TRAFFIC_CLASS; i++) {
		hw->fc.low_water[i] = IXGBE_FC_LO;
		hw->fc.high_water[i] = IXGBE_FC_HI;
	}
	hw->fc.send_xon = 1;


	/* Make sure we have a good EEPROM before we read from it */
	diag = dwc_validate_eeprom_checksum(hw, &csum);
	if (diag != DWC_SUCCESS) {
		PMD_INIT_LOG(ERR, "The EEPROM checksum is not valid: %d", diag);
		return -EIO;
	}
	
#endif //add by zs

#ifdef RTE_LIBRTE_DWC_BYPASS
#else
	diag = dwc_init_hw(hw);
#endif 

#if 0		//add by zs, 20200223
	if (diag && (hw->mac.ops.get_media_type(hw) == dwc_media_type_copper)) {
		rte_delay_ms(200);
		diag = dwc_init_hw(hw);
	}
#endif

	if (diag == DWC_ERR_SFP_NOT_PRESENT)
		diag = DWC_SUCCESS;

	if (diag == DWC_ERR_SFP_NOT_SUPPORTED)
		PMD_INIT_LOG(ERR, "Unsupported SFP+ Module");
	if (diag) {
		PMD_INIT_LOG(ERR, "Hardware Initialization Failure: %d", diag);
		return -EIO;
	}

	/* Reset the hw statistics */
	dwc_dev_stats_reset(eth_dev);

	/* disable interrupt */
	//dwc_disable_intr(hw);
	dwc_disable_intr(pdata);

	/* reset mappings for queue statistics hw counters*/
	dwc_reset_qstat_mappings(hw);

	/* Allocate memory for storing MAC addresses */
	eth_dev->data->mac_addrs = rte_zmalloc("dwc", ETHER_ADDR_LEN *
					       hw->mac.num_rar_entries, 0);
	if (eth_dev->data->mac_addrs == NULL) {
		PMD_INIT_LOG(ERR,
			     "Failed to allocate %u bytes needed to store "
			     "MAC addresses",
			     ETHER_ADDR_LEN * hw->mac.num_rar_entries);
		return -ENOMEM;
	}
	/* Copy the permanent MAC address */
	ether_addr_copy((struct ether_addr *) hw->mac.perm_addr,
			&eth_dev->data->mac_addrs[0]);

	/* Allocate memory for storing hash filter MAC addresses */
	eth_dev->data->hash_mac_addrs = rte_zmalloc("dwc", ETHER_ADDR_LEN *
						    DWC_VMDQ_NUM_UC_MAC, 0);
	if (eth_dev->data->hash_mac_addrs == NULL) {
		PMD_INIT_LOG(ERR,
			     "Failed to allocate %d bytes needed to store MAC addresses",
			     ETHER_ADDR_LEN * DWC_VMDQ_NUM_UC_MAC);
		return -ENOMEM;
	}

#if 0	//add by zs, 20200223
	/* initialize the vfta */
	memset(shadow_vfta, 0, sizeof(*shadow_vfta));

	/* initialize the hw strip bitmap*/
	memset(hwstrip, 0, sizeof(*hwstrip));

	/* initialize PF if max_vfs not zero */
	dwc_pf_host_init(eth_dev);

	ctrl_ext = DWC_READ_REG(hw, DWC_CTRL_EXT);
	/* let hardware know driver is loaded */
	ctrl_ext |= DWC_CTRL_EXT_DRV_LOAD;
	/* Set PF Reset Done bit so PF/VF Mail Ops can work */
	ctrl_ext |= DWC_CTRL_EXT_PFRSTD;
	DWC_WRITE_REG(hw, DWC_CTRL_EXT, ctrl_ext);
	DWC_WRITE_FLUSH(hw);

#endif

	if (dwc_is_sfp(hw) && hw->phy.sfp_type != dwc_sfp_type_not_present)
		PMD_INIT_LOG(DEBUG, "MAC: %d, PHY: %d, SFP+: %d",
			     (int) hw->mac.type, (int) hw->phy.type,
			     (int) hw->phy.sfp_type);
	else
		PMD_INIT_LOG(DEBUG, "MAC: %d, PHY: %d",
			     (int) hw->mac.type, (int) hw->phy.type);

	PMD_INIT_LOG(DEBUG, "port %d vendorID=0x%x deviceID=0x%x",
		     eth_dev->data->port_id, pci_dev->id.vendor_id,
		     pci_dev->id.device_id);

	rte_intr_callback_register(intr_handle,
				   dwc_dev_interrupt_handler, eth_dev);

	/* enable uio/vfio intr/eventfd mapping */
	rte_intr_enable(intr_handle);

	/* enable support intr */
	dwc_enable_intr(eth_dev);

#if 0 	//add by zs

	/* initialize filter info */
	memset(filter_info, 0,
	       sizeof(struct dwc_filter_info));

	/* initialize 5tuple filter list */
	TAILQ_INIT(&filter_info->fivetuple_list);


	/* initialize flow director filter list & hash */
	dwc_fdir_filter_init(eth_dev);

	/* initialize l2 tunnel filter list & hash */
	dwc_l2_tn_filter_init(eth_dev);


	/* initialize flow filter lists */
	ixgbe_filterlist_init();

	/* initialize bandwidth configuration info */
	memset(bw_conf, 0, sizeof(struct dwc_bw_conf));

	/* initialize Traffic Manager configuration */
	ixgbe_tm_conf_init(eth_dev);

#endif 	//add by zs 

	return 0;
}

static int
eth_dwc_dev_uninit(struct rte_eth_dev *eth_dev)
{
	struct rte_pci_device *pci_dev = RTE_ETH_DEV_TO_PCI(eth_dev);
	struct rte_intr_handle *intr_handle = &pci_dev->intr_handle;
	struct dwc_hw *hw;
	int retries = 0;
	int ret;

	PMD_INIT_FUNC_TRACE();

	if (rte_eal_process_type() != RTE_PROC_PRIMARY)
		return 0;

	hw = DWC_DEV_PRIVATE_TO_HW(eth_dev->data->dev_private);

	if (hw->adapter_stopped == 0)
		dwc_dev_close(eth_dev);

	eth_dev->dev_ops = NULL;
	eth_dev->rx_pkt_burst = NULL;
	eth_dev->tx_pkt_burst = NULL;

	/* Unlock any pending hardware semaphore */
	dwc_swfw_lock_reset(hw);

	/* disable uio intr before callback unregister */
	rte_intr_disable(intr_handle);

	do {
		ret = rte_intr_callback_unregister(intr_handle,
				dwc_dev_interrupt_handler, eth_dev);
		if (ret >= 0) {
			break;
		} else if (ret != -EAGAIN) {
			PMD_INIT_LOG(ERR,
				"intr callback unregister failed: %d",
				ret);
			return ret;
		}
		rte_delay_ms(100);
	} while (retries++ < (10 + DWC_LINK_UP_TIME));

	/* uninitialize PF if max_vfs not zero */
	dwc_pf_host_uninit(eth_dev);
	
#if 0//add by zs

	/* remove all the fdir filters & hash */
	ixgbe_fdir_filter_uninit(eth_dev);

	/* remove all the L2 tunnel filters & hash */
	ixgbe_l2_tn_filter_uninit(eth_dev);

	/* Remove all ntuple filters of the device */
	ixgbe_ntuple_filter_uninit(eth_dev);

	/* clear all the filters list */
	ixgbe_filterlist_flush();

	/* Remove all Traffic Manager configuration */
	ixgbe_tm_conf_uninit(eth_dev);

#ifdef RTE_LIBRTE_SECURITY
	rte_free(eth_dev->security_ctx);
#endif

#endif //add by zs

	return 0;
}

#if 0 //add by zs, 20200224

static int dwc_fdir_filter_init(struct rte_eth_dev *eth_dev)
{
	struct dwc_hw_fdir_info *fdir_info =
		DWC_DEV_PRIVATE_TO_FDIR_INFO(eth_dev->data->dev_private);
	char fdir_hash_name[RTE_HASH_NAMESIZE];
	struct rte_hash_parameters fdir_hash_params = {
		.name = fdir_hash_name,
		.entries = DWC_MAX_FDIR_FILTER_NUM,
		.key_len = sizeof(union dwc_atr_input),
		.hash_func = rte_hash_crc,
		.hash_func_init_val = 0,
		.socket_id = rte_socket_id(),
	};

	TAILQ_INIT(&fdir_info->fdir_list);
	snprintf(fdir_hash_name, RTE_HASH_NAMESIZE,
		 "fdir_%s", eth_dev->device->name);
	fdir_info->hash_handle = rte_hash_create(&fdir_hash_params);
	if (!fdir_info->hash_handle) {
		PMD_INIT_LOG(ERR, "Failed to create fdir hash table!");
		return -EINVAL;
	}
	fdir_info->hash_map = rte_zmalloc("dwc_xlgmac",
					  sizeof(struct dwc_fdir_filter *) *
					  DWC_MAX_FDIR_FILTER_NUM,
					  0);
	if (!fdir_info->hash_map) {
		PMD_INIT_LOG(ERR,
			     "Failed to allocate memory for fdir hash map!");
		return -ENOMEM;
	}
	fdir_info->mask_added = FALSE;

	return 0;
}

static int dwc_l2_tn_filter_init(struct rte_eth_dev *eth_dev)
{
	struct dwc_l2_tn_info *l2_tn_info =
		DWC_DEV_PRIVATE_TO_L2_TN_INFO(eth_dev->data->dev_private);
	char l2_tn_hash_name[RTE_HASH_NAMESIZE];
	struct rte_hash_parameters l2_tn_hash_params = {
		.name = l2_tn_hash_name,
		.entries = DWC_MAX_L2_TN_FILTER_NUM,
		.key_len = sizeof(struct dwc_l2_tn_key),
		.hash_func = rte_hash_crc,
		.hash_func_init_val = 0,
		.socket_id = rte_socket_id(),
	};

	TAILQ_INIT(&l2_tn_info->l2_tn_list);
	snprintf(l2_tn_hash_name, RTE_HASH_NAMESIZE,
		 "l2_tn_%s", eth_dev->device->name);
	l2_tn_info->hash_handle = rte_hash_create(&l2_tn_hash_params);
	if (!l2_tn_info->hash_handle) {
		PMD_INIT_LOG(ERR, "Failed to create L2 TN hash table!");
		return -EINVAL;
	}
	l2_tn_info->hash_map = rte_zmalloc("dwc_xlgmac",
				   sizeof(struct dwc_l2_tn_filter *) *
				   DWC_MAX_L2_TN_FILTER_NUM,
				   0);
	if (!l2_tn_info->hash_map) {
		PMD_INIT_LOG(ERR,
			"Failed to allocate memory for L2 TN hash map!");
		return -ENOMEM;
	}
	l2_tn_info->e_tag_en = FALSE;
	l2_tn_info->e_tag_fwd_en = FALSE;
	l2_tn_info->e_tag_ether_type = ETHER_TYPE_ETAG;

	return 0;
}

#endif //end add by zs, 20200224

static void
generate_random_mac_addr(struct ether_addr *mac_addr)
{
	uint64_t random;

	/* Set Organizationally Unique Identifier (OUI) prefix. */
	mac_addr->addr_bytes[0] = 0x00;
	mac_addr->addr_bytes[1] = 0x09;
	mac_addr->addr_bytes[2] = 0xC0;
	/* Force indication of locally assigned MAC address. */
	mac_addr->addr_bytes[0] |= ETHER_LOCAL_ADMIN_ADDR;
	/* Generate the last 3 bytes of the MAC address with a random number. */
	random = rte_rand();
	memcpy(&mac_addr->addr_bytes[3], &random, 3);
}

/*
 * Virtual Function device init
 */
static int
eth_dwcvf_dev_init(struct rte_eth_dev *eth_dev)
{
	int diag;
	uint32_t tc, tcs;
	struct rte_pci_device *pci_dev = RTE_ETH_DEV_TO_PCI(eth_dev);
	struct rte_intr_handle *intr_handle = &pci_dev->intr_handle;
	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(eth_dev->data->dev_private);
	struct ixgbe_vfta *shadow_vfta =
		IXGBE_DEV_PRIVATE_TO_VFTA(eth_dev->data->dev_private);
	struct dwc_hwstrip *hwstrip =
		DWC_DEV_PRIVATE_TO_HWSTRIP_BITMAP(eth_dev->data->dev_private);
	struct ether_addr *perm_addr = (struct ether_addr *) hw->mac.perm_addr;

	PMD_INIT_FUNC_TRACE();

	eth_dev->dev_ops = &dwcvf_eth_dev_ops;
	eth_dev->rx_pkt_burst = &dwc_recv_pkts;
	eth_dev->tx_pkt_burst = &dwc_xmit_pkts;

#if 0 //add by zs

	/* for secondary processes, we don't initialise any further as primary
	 * has already done this work. Only check we don't need a different
	 * RX function
	 */
	if (rte_eal_process_type() != RTE_PROC_PRIMARY) {
		struct dwc_tx_queue *txq;
		/* TX queue function in primary, set by last queue initialized
		 * Tx queue may not initialized by primary process
		 */
		if (eth_dev->data->tx_queues) {
			txq = eth_dev->data->tx_queues[eth_dev->data->nb_tx_queues - 1];
			dwc_set_tx_function(eth_dev, txq);
		} else {
			/* Use default TX function if we get here */
			PMD_INIT_LOG(NOTICE,
				     "No TX queues configured yet. Using default TX function.");
		}

		dwc_set_rx_function(eth_dev);

		return 0;
	}

	rte_eth_copy_pci_info(eth_dev, pci_dev);

	hw->device_id = pci_dev->id.device_id;
	hw->vendor_id = pci_dev->id.vendor_id;
	hw->hw_addr = (void *)pci_dev->mem_resource[0].addr;

	/* initialize the vfta */
	memset(shadow_vfta, 0, sizeof(*shadow_vfta));

	/* initialize the hw strip bitmap*/
	memset(hwstrip, 0, sizeof(*hwstrip));

	/* Initialize the shared code (base driver) */
	diag = dwc_init_shared_code(hw);
	if (diag != DWC_SUCCESS) {
		PMD_INIT_LOG(ERR, "Shared code init failed for ixgbevf: %d", diag);
		return -EIO;
	}

	/* init_mailbox_params */
	hw->mbx.ops.init_params(hw);

	/* Reset the hw statistics */
	ixgbevf_dev_stats_reset(eth_dev);

	/* Disable the interrupts for VF */
	dwcvf_intr_disable(eth_dev);

	hw->mac.num_rar_entries = 128; /* The MAX of the underlying PF */
	diag = hw->mac.ops.reset_hw(hw);

	/*
	 * The VF reset operation returns the IXGBE_ERR_INVALID_MAC_ADDR when
	 * the underlying PF driver has not assigned a MAC address to the VF.
	 * In this case, assign a random MAC address.
	 */
	if ((diag != DWC_SUCCESS) && (diag != IXGBE_ERR_INVALID_MAC_ADDR)) {
		PMD_INIT_LOG(ERR, "VF Initialization Failure: %d", diag);
		/*
		 * This error code will be propagated to the app by
		 * rte_eth_dev_reset, so use a public error code rather than
		 * the internal-only IXGBE_ERR_RESET_FAILED
		 */
		return -EAGAIN;
	}

	/* negotiate mailbox API version to use with the PF. */
	ixgbevf_negotiate_api(hw);

	/* Get Rx/Tx queue count via mailbox, which is ready after reset_hw */
	ixgbevf_get_queues(hw, &tcs, &tc);

	/* Allocate memory for storing MAC addresses */
	eth_dev->data->mac_addrs = rte_zmalloc("ixgbevf", ETHER_ADDR_LEN *
					       hw->mac.num_rar_entries, 0);
	if (eth_dev->data->mac_addrs == NULL) {
		PMD_INIT_LOG(ERR,
			     "Failed to allocate %u bytes needed to store "
			     "MAC addresses",
			     ETHER_ADDR_LEN * hw->mac.num_rar_entries);
		return -ENOMEM;
	}

	/* Generate a random MAC address, if none was assigned by PF. */
	if (is_zero_ether_addr(perm_addr)) {
		generate_random_mac_addr(perm_addr);
		diag = ixgbe_set_rar_vf(hw, 1, perm_addr->addr_bytes, 0, 1);
		if (diag) {
			rte_free(eth_dev->data->mac_addrs);
			eth_dev->data->mac_addrs = NULL;
			return diag;
		}
		PMD_INIT_LOG(INFO, "\tVF MAC address not assigned by Host PF");
		PMD_INIT_LOG(INFO, "\tAssign randomly generated MAC address "
			     "%02x:%02x:%02x:%02x:%02x:%02x",
			     perm_addr->addr_bytes[0],
			     perm_addr->addr_bytes[1],
			     perm_addr->addr_bytes[2],
			     perm_addr->addr_bytes[3],
			     perm_addr->addr_bytes[4],
			     perm_addr->addr_bytes[5]);
	}

	/* Copy the permanent MAC address */
	ether_addr_copy(perm_addr, &eth_dev->data->mac_addrs[0]);

	/* reset the hardware with the new settings */
	diag = hw->mac.ops.start_hw(hw);
	switch (diag) {
	case  0:
		break;

	default:
		PMD_INIT_LOG(ERR, "VF Initialization Failure: %d", diag);
		return -EIO;
	}

	rte_intr_callback_register(intr_handle,
				   dwcvf_dev_interrupt_handler, eth_dev);
	rte_intr_enable(intr_handle);
	dwcvf_intr_enable(eth_dev);

	PMD_INIT_LOG(DEBUG, "port %d vendorID=0x%x deviceID=0x%x mac.type=%s",
		     eth_dev->data->port_id, pci_dev->id.vendor_id,
		     pci_dev->id.device_id, "ixgbe_mac_82599_vf");

#endif //add by zs

	return 0;
}

/* Virtual Function device uninit */

static int
eth_dwcvf_dev_uninit(struct rte_eth_dev *eth_dev)
{
	struct rte_pci_device *pci_dev = RTE_ETH_DEV_TO_PCI(eth_dev);
	struct rte_intr_handle *intr_handle = &pci_dev->intr_handle;
	struct dwc_hw *hw;

	PMD_INIT_FUNC_TRACE();

	if (rte_eal_process_type() != RTE_PROC_PRIMARY)
		return 0;

	hw = DWC_DEV_PRIVATE_TO_HW(eth_dev->data->dev_private);

	if (hw->adapter_stopped == 0)
		dwcvf_dev_close(eth_dev);

	eth_dev->dev_ops = NULL;
	eth_dev->rx_pkt_burst = NULL;
	eth_dev->tx_pkt_burst = NULL;

	/* Disable the interrupts for VF */
	dwcvf_intr_disable(eth_dev);

	rte_intr_disable(intr_handle);
	rte_intr_callback_unregister(intr_handle,
				     dwcvf_dev_interrupt_handler, eth_dev);

	return 0;
}

static int
eth_dwc_pci_probe(struct rte_pci_driver *pci_drv __rte_unused,
		struct rte_pci_device *pci_dev)
{
	char name[RTE_ETH_NAME_MAX_LEN];
	struct rte_eth_dev *pf_ethdev;
	struct rte_eth_devargs eth_da;
	int i, retval;

	if (pci_dev->device.devargs) {
		retval = rte_eth_devargs_parse(pci_dev->device.devargs->args,
				&eth_da);
		if (retval)
			return retval;
	} else
		memset(&eth_da, 0, sizeof(eth_da));

	retval = rte_eth_dev_create(&pci_dev->device, pci_dev->device.name,
		sizeof(struct dwc_adapter),
		eth_dev_pci_specific_init, pci_dev,
		eth_dwc_dev_init, NULL);

	if (retval || eth_da.nb_representor_ports < 1)
		return retval;

	pf_ethdev = rte_eth_dev_allocated(pci_dev->device.name);
	if (pf_ethdev == NULL)
		return -ENODEV;

#if 0 	//add by zs 
	/* probe VF representor ports */
	for (i = 0; i < eth_da.nb_representor_ports; i++) {
		struct dwc_vf_info *vfinfo;
		struct ixgbe_vf_representor representor;

		vfinfo = *DWC_DEV_PRIVATE_TO_P_VFDATA(
			pf_ethdev->data->dev_private);
		if (vfinfo == NULL) {
			PMD_DRV_LOG(ERR,
				"no virtual functions supported by PF");
			break;
		}

		representor.vf_id = eth_da.representor_ports[i];
		representor.switch_domain_id = vfinfo->switch_domain_id;
		representor.pf_ethdev = pf_ethdev;

		/* representor port net_bdf_port */
		snprintf(name, sizeof(name), "net_%s_representor_%d",
			pci_dev->device.name,
			eth_da.representor_ports[i]);

		retval = rte_eth_dev_create(&pci_dev->device, name,
			sizeof(struct ixgbe_vf_representor), NULL, NULL,
			ixgbe_vf_representor_init, &representor);

		if (retval)
			PMD_DRV_LOG(ERR, "failed to create ixgbe vf "
				"representor %s.", name);
	}

#endif 	//add by zs 

	return 0;
}

static int eth_dwc_pci_remove(struct rte_pci_device *pci_dev)
{
	struct rte_eth_dev *ethdev;

	ethdev = rte_eth_dev_allocated(pci_dev->device.name);
	if (!ethdev)
		return -ENODEV;

#if 0	//add by zs, 20200224
	if (ethdev->data->dev_flags & RTE_ETH_DEV_REPRESENTOR)
		return rte_eth_dev_destroy(ethdev, ixgbe_vf_representor_uninit);
	else
#endif	//end add by zs, 20200224
		return rte_eth_dev_destroy(ethdev, eth_dwc_dev_uninit);
}

static struct rte_pci_driver rte_dwc_pmd = {
	.id_table = pci_id_dwc_map,
	.drv_flags = RTE_PCI_DRV_NEED_MAPPING | RTE_PCI_DRV_INTR_LSC |
		     RTE_PCI_DRV_IOVA_AS_VA,
	.probe = eth_dwc_pci_probe,
	.remove = eth_dwc_pci_remove,
};

static int eth_dwcvf_pci_probe(struct rte_pci_driver *pci_drv __rte_unused,
	struct rte_pci_device *pci_dev)
{
	return rte_eth_dev_pci_generic_probe(pci_dev,
		sizeof(struct dwc_adapter), eth_dwcvf_dev_init);
}

static int eth_dwcvf_pci_remove(struct rte_pci_device *pci_dev)
{
	return rte_eth_dev_pci_generic_remove(pci_dev, eth_dwcvf_dev_uninit);
}

/*
 * virtual function driver struct
 */
static struct rte_pci_driver rte_dwcvf_pmd = {
	.id_table = pci_id_dwcvf_map,
	.drv_flags = RTE_PCI_DRV_NEED_MAPPING | RTE_PCI_DRV_IOVA_AS_VA,
	.probe = eth_dwcvf_pci_probe,
	.remove = eth_dwcvf_pci_remove,
};

static int
dwc_vlan_offload_config(struct rte_eth_dev *dev, int mask)
{
	struct rte_eth_rxmode *rxmode;
	rxmode = &dev->data->dev_conf.rxmode;

#if 0 //add by zs

	if (mask & ETH_VLAN_STRIP_MASK) {
		ixgbe_vlan_hw_strip_config(dev);
	}

	if (mask & ETH_VLAN_FILTER_MASK) {
		if (rxmode->offloads & DEV_RX_OFFLOAD_VLAN_FILTER)
			ixgbe_vlan_hw_filter_enable(dev);
		else
			ixgbe_vlan_hw_filter_disable(dev);
	}

	if (mask & ETH_VLAN_EXTEND_MASK) {
		if (rxmode->offloads & DEV_RX_OFFLOAD_VLAN_EXTEND)
			ixgbe_vlan_hw_extend_enable(dev);
		else
			ixgbe_vlan_hw_extend_disable(dev);
	}

#endif  //add by zs

	return 0;
}


static void
dwc_vmdq_vlan_hw_filter_enable(struct rte_eth_dev *dev)
{
	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	/* VLNCTRL: enable vlan filtering and allow all vlan tags through */
	uint32_t vlanctrl = DWC_READ_REG(hw, DWC_VLNCTRL);

	vlanctrl |= DWC_VLNCTRL_VFE; /* enable vlan filters */
	DWC_WRITE_REG(hw, DWC_VLNCTRL, vlanctrl);
}

static int
dwc_check_vf_rss_rxq_num(struct rte_eth_dev *dev, uint16_t nb_rx_q)
{
	struct rte_pci_device *pci_dev = RTE_ETH_DEV_TO_PCI(dev);

	switch (nb_rx_q) {
	case 1:
	case 2:
		RTE_ETH_DEV_SRIOV(dev).active = ETH_64_POOLS;
		break;
	case 4:
		RTE_ETH_DEV_SRIOV(dev).active = ETH_32_POOLS;
		break;
	default:
		return -EINVAL;
	}

	RTE_ETH_DEV_SRIOV(dev).nb_q_per_pool =
		DWC_MAX_RX_QUEUE_NUM / RTE_ETH_DEV_SRIOV(dev).active;
	RTE_ETH_DEV_SRIOV(dev).def_pool_q_idx =
		pci_dev->max_vfs * RTE_ETH_DEV_SRIOV(dev).nb_q_per_pool;
	return 0;
}

static int
dwc_check_mq_mode(struct rte_eth_dev *dev)
{
	struct rte_eth_conf *dev_conf = &dev->data->dev_conf;
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	uint16_t nb_rx_q = dev->data->nb_rx_queues;
	uint16_t nb_tx_q = dev->data->nb_tx_queues;

	if (RTE_ETH_DEV_SRIOV(dev).active != 0) {
		/* check multi-queue mode */
		switch (dev_conf->rxmode.mq_mode) {
		case ETH_MQ_RX_VMDQ_DCB:
			PMD_INIT_LOG(INFO, "ETH_MQ_RX_VMDQ_DCB mode supported in SRIOV");
			break;
		case ETH_MQ_RX_VMDQ_DCB_RSS:
			/* DCB/RSS VMDQ in SRIOV mode, not implement yet */
			PMD_INIT_LOG(ERR, "SRIOV active,"
					" unsupported mq_mode rx %d.",
					dev_conf->rxmode.mq_mode);
			return -EINVAL;
		case ETH_MQ_RX_RSS:
		case ETH_MQ_RX_VMDQ_RSS:
			dev->data->dev_conf.rxmode.mq_mode = ETH_MQ_RX_VMDQ_RSS;
			if (nb_rx_q <= RTE_ETH_DEV_SRIOV(dev).nb_q_per_pool)
				if (dwc_check_vf_rss_rxq_num(dev, nb_rx_q)) {
					PMD_INIT_LOG(ERR, "SRIOV is active,"
						" invalid queue number"
						" for VMDQ RSS, allowed"
						" value are 1, 2 or 4.");
					return -EINVAL;
				}
			break;
		case ETH_MQ_RX_VMDQ_ONLY:
		case ETH_MQ_RX_NONE:
			/* if nothing mq mode configure, use default scheme */
			dev->data->dev_conf.rxmode.mq_mode = ETH_MQ_RX_VMDQ_ONLY;
			break;
		default: /* ETH_MQ_RX_DCB, ETH_MQ_RX_DCB_RSS or ETH_MQ_TX_DCB*/
			/* SRIOV only works in VMDq enable mode */
			PMD_INIT_LOG(ERR, "SRIOV is active,"
					" wrong mq_mode rx %d.",
					dev_conf->rxmode.mq_mode);
			return -EINVAL;
		}

		switch (dev_conf->txmode.mq_mode) {
		case ETH_MQ_TX_VMDQ_DCB:
			PMD_INIT_LOG(INFO, "ETH_MQ_TX_VMDQ_DCB mode supported in SRIOV");
			dev->data->dev_conf.txmode.mq_mode = ETH_MQ_TX_VMDQ_DCB;
			break;
		default: /* ETH_MQ_TX_VMDQ_ONLY or ETH_MQ_TX_NONE */
			dev->data->dev_conf.txmode.mq_mode = ETH_MQ_TX_VMDQ_ONLY;
			break;
		}

		/* check valid queue number */
		if ((nb_rx_q > RTE_ETH_DEV_SRIOV(dev).nb_q_per_pool) ||
		    (nb_tx_q > RTE_ETH_DEV_SRIOV(dev).nb_q_per_pool)) {
			PMD_INIT_LOG(ERR, "SRIOV is active,"
					" nb_rx_q=%d nb_tx_q=%d queue number"
					" must be less than or equal to %d.",
					nb_rx_q, nb_tx_q,
					RTE_ETH_DEV_SRIOV(dev).nb_q_per_pool);
			return -EINVAL;
		}
	} else {
		if (dev_conf->rxmode.mq_mode == ETH_MQ_RX_VMDQ_DCB_RSS) {
			PMD_INIT_LOG(ERR, "VMDQ+DCB+RSS mq_mode is"
					  " not supported.");
			return -EINVAL;
		}
		/* check configuration for vmdb+dcb mode */
		if (dev_conf->rxmode.mq_mode == ETH_MQ_RX_VMDQ_DCB) {
			const struct rte_eth_vmdq_dcb_conf *conf;

			if (nb_rx_q != DWC_VMDQ_DCB_NB_QUEUES) {
				PMD_INIT_LOG(ERR, "VMDQ+DCB, nb_rx_q != %d.",
						DWC_VMDQ_DCB_NB_QUEUES);
				return -EINVAL;
			}
			conf = &dev_conf->rx_adv_conf.vmdq_dcb_conf;
			if (!(conf->nb_queue_pools == ETH_16_POOLS ||
			       conf->nb_queue_pools == ETH_32_POOLS)) {
				PMD_INIT_LOG(ERR, "VMDQ+DCB selected,"
						" nb_queue_pools must be %d or %d.",
						ETH_16_POOLS, ETH_32_POOLS);
				return -EINVAL;
			}
		}
		if (dev_conf->txmode.mq_mode == ETH_MQ_TX_VMDQ_DCB) {
			const struct rte_eth_vmdq_dcb_tx_conf *conf;

			if (nb_tx_q != DWC_VMDQ_DCB_NB_QUEUES) {
				PMD_INIT_LOG(ERR, "VMDQ+DCB, nb_tx_q != %d",
						 DWC_VMDQ_DCB_NB_QUEUES);
				return -EINVAL;
			}
			conf = &dev_conf->tx_adv_conf.vmdq_dcb_tx_conf;
			if (!(conf->nb_queue_pools == ETH_16_POOLS ||
			       conf->nb_queue_pools == ETH_32_POOLS)) {
				PMD_INIT_LOG(ERR, "VMDQ+DCB selected,"
						" nb_queue_pools != %d and"
						" nb_queue_pools != %d.",
						ETH_16_POOLS, ETH_32_POOLS);
				return -EINVAL;
			}
		}

		/* For DCB mode check our configuration before we go further */
		if (dev_conf->rxmode.mq_mode == ETH_MQ_RX_DCB) {
			const struct rte_eth_dcb_rx_conf *conf;

			conf = &dev_conf->rx_adv_conf.dcb_rx_conf;
			if (!(conf->nb_tcs == ETH_4_TCS ||
			       conf->nb_tcs == ETH_8_TCS)) {
				PMD_INIT_LOG(ERR, "DCB selected, nb_tcs != %d"
						" and nb_tcs != %d.",
						ETH_4_TCS, ETH_8_TCS);
				return -EINVAL;
			}
		}

		if (dev_conf->txmode.mq_mode == ETH_MQ_TX_DCB) {
			const struct rte_eth_dcb_tx_conf *conf;

			conf = &dev_conf->tx_adv_conf.dcb_tx_conf;
			if (!(conf->nb_tcs == ETH_4_TCS ||
			       conf->nb_tcs == ETH_8_TCS)) {
				PMD_INIT_LOG(ERR, "DCB selected, nb_tcs != %d"
						" and nb_tcs != %d.",
						ETH_4_TCS, ETH_8_TCS);
				return -EINVAL;
			}
		}

		/*
		 * When DCB/VT is off, maximum number of queues changes,
		 * except for 82598EB, which remains constant.
		 */
		if (dev_conf->txmode.mq_mode == ETH_MQ_TX_NONE &&
				hw->mac.type != dwc_mac_1) {
			if (nb_tx_q > IXGBE_NONE_MODE_TX_NB_QUEUES) {
				PMD_INIT_LOG(ERR,
					     "Neither VT nor DCB are enabled, "
					     "nb_tx_q > %d.",
					     IXGBE_NONE_MODE_TX_NB_QUEUES);
				return -EINVAL;
			}
		}
	}
	return 0;
}

static int
dwc_dev_configure(struct rte_eth_dev *dev)
{
	struct dwc_interrupt *intr =
		DWC_DEV_PRIVATE_TO_INTR(dev->data->dev_private);
	struct dwc_adapter *adapter =
		(struct dwc_adapter *)dev->data->dev_private;
	int ret;

	PMD_INIT_FUNC_TRACE();
	/* multipe queue mode checking */
	ret  = dwc_check_mq_mode(dev);
	if (ret != 0) {
		PMD_DRV_LOG(ERR, "dwc_check_mq_mode fails with %d.",
			    ret);
		return ret;
	}

	/* set flag to update link status after init */
	intr->flags |= IXGBE_FLAG_NEED_LINK_UPDATE;

	/*
	 * Initialize to TRUE. If any of Rx queues doesn't meet the bulk
	 * allocation or vector Rx preconditions we will reset it.
	 */
	adapter->rx_bulk_alloc_allowed = true;
	adapter->rx_vec_allowed = true;

	return 0;
}

static void
dwc_dev_phy_intr_setup(struct rte_eth_dev *dev)
{
	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	struct dwc_interrupt *intr =
		DWC_DEV_PRIVATE_TO_INTR(dev->data->dev_private);
	uint32_t gpie;

#if 0 //add by zs

	/* only set up it on X550EM_X */
	if (hw->mac.type == ixgbe_mac_X550EM_x) {
		gpie = DWC_READ_REG(hw, IXGBE_GPIE);
		gpie |= IXGBE_SDP0_GPIEN_X550EM_x;
		DWC_WRITE_REG(hw, IXGBE_GPIE, gpie);
		if (hw->phy.type == ixgbe_phy_x550em_ext_t)
			intr->mask |= IXGBE_EICR_GPI_SDP0_X550EM_x;
	}

#endif //add by zs
}

int
dwc_set_vf_rate_limit(struct rte_eth_dev *dev, uint16_t vf,
			uint16_t tx_rate, uint64_t q_msk)
{
	struct dwc_hw *hw;
	struct dwc_vf_info *vfinfo;
	struct rte_eth_link link;
	uint8_t  nb_q_per_pool;
	uint32_t queue_stride;
	uint32_t queue_idx, idx = 0, vf_idx;
	uint32_t queue_end;
	uint16_t total_rate = 0;
	struct rte_pci_device *pci_dev;

#if 0 //add by zs

	pci_dev = RTE_ETH_DEV_TO_PCI(dev);
	rte_eth_link_get_nowait(dev->data->port_id, &link);

	if (vf >= pci_dev->max_vfs)
		return -EINVAL;

	if (tx_rate > link.link_speed)
		return -EINVAL;

	if (q_msk == 0)
		return 0;

	hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	vfinfo = *(DWC_DEV_PRIVATE_TO_P_VFDATA(dev->data->dev_private));
	nb_q_per_pool = RTE_ETH_DEV_SRIOV(dev).nb_q_per_pool;
	queue_stride = DWC_MAX_RX_QUEUE_NUM / RTE_ETH_DEV_SRIOV(dev).active;
	queue_idx = vf * queue_stride;
	queue_end = queue_idx + nb_q_per_pool - 1;
	if (queue_end >= hw->mac.max_tx_queues)
		return -EINVAL;

	if (vfinfo) {
		for (vf_idx = 0; vf_idx < pci_dev->max_vfs; vf_idx++) {
			if (vf_idx == vf)
				continue;
			for (idx = 0; idx < RTE_DIM(vfinfo[vf_idx].tx_rate);
				idx++)
				total_rate += vfinfo[vf_idx].tx_rate[idx];
		}
	} else {
		return -EINVAL;
	}

	/* Store tx_rate for this vf. */
	for (idx = 0; idx < nb_q_per_pool; idx++) {
		if (((uint64_t)0x1 << idx) & q_msk) {
			if (vfinfo[vf].tx_rate[idx] != tx_rate)
				vfinfo[vf].tx_rate[idx] = tx_rate;
			total_rate += tx_rate;
		}
	}

	if (total_rate > dev->data->dev_link.link_speed) {
		/* Reset stored TX rate of the VF if it causes exceed
		 * link speed.
		 */
		memset(vfinfo[vf].tx_rate, 0, sizeof(vfinfo[vf].tx_rate));
		return -EINVAL;
	}

	/* Set RTTBCNRC of each queue/pool for vf X  */
	for (; queue_idx <= queue_end; queue_idx++) {
		if (0x1 & q_msk)
			ixgbe_set_queue_rate_limit(dev, queue_idx, tx_rate);
		q_msk = q_msk >> 1;
	}

#endif //add by zs

	return 0;
}

/*
 * Configure device link speed and setup link.
 * It returns 0 on success.
 */
static int
dwc_dev_start(struct rte_eth_dev *dev)
{
	struct mac_pdata *pdata =
		DWC_DEV_PRIVATE_TO_PDATA(dev->data->dev_private);
    int ret;
	ret = mac_start(pdata);
	return ret;
	
#if 0 	//add by zs, 20200224

	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	struct dwc_vf_info *vfinfo =
		*DWC_DEV_PRIVATE_TO_P_VFDATA(dev->data->dev_private);
	struct rte_pci_device *pci_dev = RTE_ETH_DEV_TO_PCI(dev);
	struct rte_intr_handle *intr_handle = &pci_dev->intr_handle;
	uint32_t intr_vector = 0;
	int err, link_up = 0, negotiate = 0;
	uint32_t speed = 0;
	uint32_t allowed_speeds = 0;
	int mask = 0;
	int status;
	uint16_t vf, idx;
	uint32_t *link_speeds;
	struct dwc_tm_conf *tm_conf =
		DWC_DEV_PRIVATE_TO_TM_CONF(dev->data->dev_private);

	PMD_INIT_FUNC_TRACE();

	/* IXGBE devices don't support:
	*    - half duplex (checked afterwards for valid speeds)
	*    - fixed speed: TODO implement
	*/
	if (dev->data->dev_conf.link_speeds & ETH_LINK_SPEED_FIXED) {
		PMD_INIT_LOG(ERR,
		"Invalid link_speeds for port %u, fix speed not supported",
				dev->data->port_id);
		return -EINVAL;
	}

	/* Stop the link setup handler before resetting the HW. */
	rte_eal_alarm_cancel(dwc_dev_setup_link_alarm_handler, dev);

	/* disable uio/vfio intr/eventfd mapping */
	rte_intr_disable(intr_handle);

	/* stop adapter */
	hw->adapter_stopped = 0;
	dwc_stop_adapter(hw);

	/* reinitialize adapter
	 * this calls reset and start
	 */
	status = dwc_pf_reset_hw(hw);
	if (status != 0)
		return -1;
	
	//hw->mac.ops.start_hw(hw);
	hw->mac.ops.init(hw);
	hw->mac.get_link_status = true;

	/* configure PF module if SRIOV enabled */
	dwc_pf_host_configure(dev);

	dwc_dev_phy_intr_setup(dev);

	/* check and configure queue intr-vector mapping */
	if ((rte_intr_cap_multiple(intr_handle) ||
	     !RTE_ETH_DEV_SRIOV(dev).active) &&
	    dev->data->dev_conf.intr_conf.rxq != 0) {
		intr_vector = dev->data->nb_rx_queues;
		if (intr_vector > DWC_MAX_INTR_QUEUE_NUM) {
			PMD_INIT_LOG(ERR, "At most %d intr queues supported",
					DWC_MAX_INTR_QUEUE_NUM);
			return -ENOTSUP;
		}
		if (rte_intr_efd_enable(intr_handle, intr_vector))
			return -1;
	}

	if (rte_intr_dp_is_en(intr_handle) && !intr_handle->intr_vec) {
		intr_handle->intr_vec =
			rte_zmalloc("intr_vec",
				    dev->data->nb_rx_queues * sizeof(int), 0);
		if (intr_handle->intr_vec == NULL) {
			PMD_INIT_LOG(ERR, "Failed to allocate %d rx_queues"
				     " intr_vec", dev->data->nb_rx_queues);
			return -ENOMEM;
		}
	}

	/* confiugre msix for sleep until rx interrupt */
	dwc_configure_msix(dev);

	/* initialize transmission unit */
	dwc_dev_tx_init(dev);

	/* This can fail when allocating mbufs for descriptor rings */
	err = dwc_dev_rx_init(dev);
	if (err) {
		PMD_INIT_LOG(ERR, "Unable to initialize RX hardware");
		goto error;
	}

	mask = ETH_VLAN_STRIP_MASK | ETH_VLAN_FILTER_MASK |
		ETH_VLAN_EXTEND_MASK;
	err = dwc_vlan_offload_config(dev, mask);
	if (err) {
		PMD_INIT_LOG(ERR, "Unable to set VLAN offload");
		goto error;
	}

	if (dev->data->dev_conf.rxmode.mq_mode == ETH_MQ_RX_VMDQ_ONLY) {
		/* Enable vlan filtering for VMDq */
		dwc_vmdq_vlan_hw_filter_enable(dev);
	}

	/* Configure DCB hw */
	ixgbe_configure_dcb(dev);

	if (dev->data->dev_conf.fdir_conf.mode != RTE_FDIR_MODE_NONE) {
		err = ixgbe_fdir_configure(dev);
		if (err)
			goto error;
	}

	/* Restore vf rate limit */
	if (vfinfo != NULL) {
		for (vf = 0; vf < pci_dev->max_vfs; vf++)
			for (idx = 0; idx < IXGBE_MAX_QUEUE_NUM_PER_VF; idx++)
				if (vfinfo[vf].tx_rate[idx] != 0)
					dwc_set_vf_rate_limit(
						dev, vf,
						vfinfo[vf].tx_rate[idx],
						1 << idx);
	}

	ixgbe_restore_statistics_mapping(dev);

	err = dwc_dev_rxtx_start(dev);
	if (err < 0) {
		PMD_INIT_LOG(ERR, "Unable to start rxtx queues");
		goto error;
	}

	/* Skip link setup if loopback mode is enabled for 82599. */
	if (hw->mac.type == ixgbe_mac_82599EB &&
			dev->data->dev_conf.lpbk_mode == DWC_LPBK_82599_TX_RX)
		goto skip_link_setup;

	if (dwc_is_sfp(hw) && hw->phy.multispeed_fiber) {
		err = hw->mac.ops.setup_sfp(hw);
		if (err)
			goto error;
	}

	if (hw->mac.ops.get_media_type(hw) == dwc_media_type_copper) {
		/* Turn on the copper */
		dwc_set_phy_power(hw, true);
	} else {
		/* Turn on the laser */
		dwc_enable_tx_laser(hw);
	}

	err = dwc_check_link(hw, &speed, &link_up, 0);
	if (err)
		goto error;

	dev->data->dev_link.link_status = link_up;

/*	err = dwc_get_link_capabilities(hw, &speed, &negotiate);	//modify by zs, 20200224
	if (err)
		goto error;
*/

	speed=SPEED_10G;	
	negotiate=true;

	switch (hw->mac.type) {

	default:
		allowed_speeds = ETH_LINK_SPEED_100M | ETH_LINK_SPEED_1G |
			ETH_LINK_SPEED_10G|ETH_LINK_SPEED_25G|
			ETH_LINK_SPEED_40G|ETH_LINK_SPEED_100G;
	}

	link_speeds = &dev->data->dev_conf.link_speeds;
	if (*link_speeds & ~allowed_speeds) {
		PMD_INIT_LOG(ERR, "Invalid link setting");
		goto error;
	}

	speed = 0x0;
	if (*link_speeds == ETH_LINK_SPEED_AUTONEG) {
		switch (hw->mac.type) {
		case dwc_mac_1:
			speed = DWC_LINK_SPEED_82598_AUTONEG;
			break;
		default:
			speed = DWC_LINK_SPEED_82599_AUTONEG;
		}
	} else {
		if (*link_speeds & ETH_LINK_SPEED_10G)
			speed |= DWC_LINK_SPEED_10GB_FULL;
		if (*link_speeds & ETH_LINK_SPEED_5G)
			speed |= DWC_LINK_SPEED_5GB_FULL;
		if (*link_speeds & ETH_LINK_SPEED_2_5G)
			speed |= DWC_LINK_SPEED_2_5GB_FULL;
		if (*link_speeds & ETH_LINK_SPEED_1G)
			speed |= DWC_LINK_SPEED_1GB_FULL;
		if (*link_speeds & ETH_LINK_SPEED_100M)
			speed |= DWC_LINK_SPEED_100_FULL;
	}

	err = dwc_setup_link(hw, speed, link_up);
	if (err)
		goto error;
	
skip_link_setup:

	if (rte_intr_allow_others(intr_handle)) {
		/* check if lsc interrupt is enabled */
		if (dev->data->dev_conf.intr_conf.lsc != 0)
			dwc_dev_lsc_interrupt_setup(dev, TRUE);
		else
			dwc_dev_lsc_interrupt_setup(dev, FALSE);
//		dwc_dev_macsec_interrupt_setup(dev);	 	//add by zs, 20200224	
	} else {
		rte_intr_callback_unregister(intr_handle,
					     dwc_dev_interrupt_handler, dev);
		if (dev->data->dev_conf.intr_conf.lsc != 0)
			PMD_INIT_LOG(INFO, "lsc won't enable because of"
				     " no intr multiplex");
	}

	/* check if rxq interrupt is enabled */
	if (dev->data->dev_conf.intr_conf.rxq != 0 &&
	    rte_intr_dp_is_en(intr_handle))
		dwc_dev_rxq_interrupt_setup(dev);
	
	/* enable uio/vfio intr/eventfd mapping */
	rte_intr_enable(intr_handle);

	/* resume enabled intr since hw reset */
	dwc_enable_intr(dev);

	dwc_l2_tunnel_conf(dev);
	dwc_filter_restore(dev);

	if (tm_conf->root && !tm_conf->committed)
		PMD_DRV_LOG(WARNING,
			    "please call hierarchy_commit() "
			    "before starting the port");

	/*
	 * Update link status right before return, because it may
	 * start link configuration process in a separate thread.
	 */
	dwc_dev_link_update(dev, 0);
	
	return 0;

error:
	PMD_INIT_LOG(ERR, "failure in dwc_dev_start(): %d", err);
	dwc_dev_clear_queues(dev);
	return -EIO;
	
#endif 	//end add by zs, 20200224	
}

/*
 * Stop device: disable rx and tx functions to allow for reconfiguring.
 */
static void
dwc_dev_stop(struct rte_eth_dev *dev)
{

	struct mac_pdata *pdata =
		DWC_DEV_PRIVATE_TO_PDATA(dev->data->dev_private);
    int ret;
	ret = mac_stop(pdata);
	return ret;

#if 0	//add by zs, 20200224

	struct rte_eth_link link;
	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	struct dwc_vf_info *vfinfo =
		*DWC_DEV_PRIVATE_TO_P_VFDATA(dev->data->dev_private);
	struct rte_pci_device *pci_dev = RTE_ETH_DEV_TO_PCI(dev);
	struct rte_intr_handle *intr_handle = &pci_dev->intr_handle;
	int vf;
	struct dwc_tm_conf *tm_conf =
		DWC_DEV_PRIVATE_TO_TM_CONF(dev->data->dev_private);

	PMD_INIT_FUNC_TRACE();

	rte_eal_alarm_cancel(dwc_dev_setup_link_alarm_handler, dev);

	/* disable interrupts */
	dwc_disable_intr(hw);

	/* reset the NIC */
	dwc_pf_reset_hw(hw);
	hw->adapter_stopped = 0;

	/* stop adapter */
	dwc_stop_adapter(hw);

	for (vf = 0; vfinfo != NULL && vf < pci_dev->max_vfs; vf++)
		vfinfo[vf].clear_to_send = false;

	if (hw->mac.ops.get_media_type(hw) == dwc_media_type_copper) {
		/* Turn off the copper */
		dwc_set_phy_power(hw, false);
	} else {
		/* Turn off the laser */
		dwc_disable_tx_laser(hw);
	}

	dwc_dev_clear_queues(dev);

	/* Clear stored conf */
	dev->data->scattered_rx = 0;
	dev->data->lro = 0;

	/* Clear recorded link status */
	memset(&link, 0, sizeof(link));
	rte_eth_linkstatus_set(dev, &link);

	if (!rte_intr_allow_others(intr_handle))
		/* resume to the default handler */
		rte_intr_callback_register(intr_handle,
					   dwc_dev_interrupt_handler,
					   (void *)dev);

	/* Clean datapath event and queue/vec mapping */
	rte_intr_efd_disable(intr_handle);
	if (intr_handle->intr_vec != NULL) {
		rte_free(intr_handle->intr_vec);
		intr_handle->intr_vec = NULL;
	}

	/* reset hierarchy commit */
	tm_conf->committed = false;
	
#endif  //add by zs, 20200224
}

/*
 * Set device link up: enable tx.
 */
static int
dwc_dev_set_link_up(struct rte_eth_dev *dev)
{
#if 0	//add by zs, 20200224
	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);

	if (hw->mac.ops.get_media_type(hw) == dwc_media_type_copper) {
		/* Turn on the copper */
		dwc_set_phy_power(hw, true);
	} else {
		/* Turn on the laser */
		dwc_enable_tx_laser(hw);
	}
#endif //end add by zs, 20200224

	return 0;
}

/*
 * Set device link down: disable tx.
 */
static int
dwc_dev_set_link_down(struct rte_eth_dev *dev)
{
#if 0	//add by zs, 20200224
	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);

	if (hw->mac.ops.get_media_type(hw) == dwc_media_type_copper) {
		/* Turn off the copper */
		dwc_set_phy_power(hw, false);
	} else {
		/* Turn off the laser */
		dwc_disable_tx_laser(hw);
	}
#endif //end add by zs, 20200224

	return 0;
}

/*
 * Reset and stop device.
 */
static void
dwc_dev_close(struct rte_eth_dev *dev)
{

	struct mac_pdata *pdata =
		DWC_DEV_PRIVATE_TO_PDATA(dev->data->dev_private);
    int ret;
	ret = mac_close(pdata);
	return ret;

#if 0//add by zs

	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);

	PMD_INIT_FUNC_TRACE();

	dwc_pf_reset_hw(hw);

	dwc_dev_stop(dev);
	hw->adapter_stopped = 1;

	dwc_dev_free_queues(dev);

	dwc_disable_pcie_master(hw);


	/* reprogram the RAR[0] in case user changed it. */
	ixgbe_set_rar(hw, 0, hw->mac.addr, 0, IXGBE_RAH_AV);

#endif //add by zs

}

/*
 * Reset PF device.
 */
static int
dwc_dev_reset(struct rte_eth_dev *dev)
{
	struct mac_pdata *pdata =
		DWC_DEV_PRIVATE_TO_PDATA(dev->data->dev_private);
	int ret;
	ret = mac_restart_dev(pdata);
	return ret;

#if 0	//add by zs
	int ret;

	/* When a DPDK PMD PF begin to reset PF port, it should notify all
	 * its VF to make them align with it. The detailed notification
	 * mechanism is PMD specific. As to ixgbe PF, it is rather complex.
	 * To avoid unexpected behavior in VF, currently reset of PF with
	 * SR-IOV activation is not supported. It might be supported later.
	 */
	if (dev->data->sriov.active)
		return -ENOTSUP;

	ret = eth_dwc_dev_uninit(dev);
	if (ret)
		return ret;

	ret = eth_dwc_dev_init(dev, NULL);

	return ret;
	
#endif	//add by zs
}

static void
dwc_read_stats_registers(struct dwc_hw *hw,
			   struct dwc_hw_stats *hw_stats,
			   struct dwc_macsec_stats *macsec_stats,
			   uint64_t *total_missed_rx, uint64_t *total_qbrc,
			   uint64_t *total_qprc, uint64_t *total_qprdc)
{
	uint32_t bprc, lxon, lxoff, total;
	uint32_t delta_gprc = 0;
	unsigned i;
	/* Workaround for RX byte count not including CRC bytes when CRC
	 * strip is enabled. CRC bytes are removed from counters when crc_strip
	 * is disabled.
	 */

#if 0 //add by zs
	
	int crc_strip = (DWC_READ_REG(hw, IXGBE_HLREG0) &
			IXGBE_HLREG0_RXCRCSTRP);

	hw_stats->crcerrs += DWC_READ_REG(hw, IXGBE_CRCERRS);
	hw_stats->illerrc += DWC_READ_REG(hw, IXGBE_ILLERRC);
	hw_stats->errbc += DWC_READ_REG(hw, IXGBE_ERRBC);
	hw_stats->mspdc += DWC_READ_REG(hw, IXGBE_MSPDC);

	for (i = 0; i < 8; i++) {
		uint32_t mp = DWC_READ_REG(hw, IXGBE_MPC(i));

		/* global total per queue */
		hw_stats->mpc[i] += mp;
		/* Running comprehensive total for stats display */
		*total_missed_rx += hw_stats->mpc[i];
		if (hw->mac.type == dwc_mac_1) {
			hw_stats->rnbc[i] +=
			    DWC_READ_REG(hw, IXGBE_RNBC(i));
			hw_stats->pxonrxc[i] +=
				DWC_READ_REG(hw, IXGBE_PXONRXC(i));
			hw_stats->pxoffrxc[i] +=
				DWC_READ_REG(hw, IXGBE_PXOFFRXC(i));
		} else {
			hw_stats->pxonrxc[i] +=
				DWC_READ_REG(hw, IXGBE_PXONRXCNT(i));
			hw_stats->pxoffrxc[i] +=
				DWC_READ_REG(hw, IXGBE_PXOFFRXCNT(i));
			hw_stats->pxon2offc[i] +=
				DWC_READ_REG(hw, IXGBE_PXON2OFFCNT(i));
		}
		hw_stats->pxontxc[i] +=
		    DWC_READ_REG(hw, IXGBE_PXONTXC(i));
		hw_stats->pxofftxc[i] +=
		    DWC_READ_REG(hw, IXGBE_PXOFFTXC(i));
	}
	for (i = 0; i < IXGBE_QUEUE_STAT_COUNTERS; i++) {
		uint32_t delta_qprc = DWC_READ_REG(hw, IXGBE_QPRC(i));
		uint32_t delta_qptc = DWC_READ_REG(hw, IXGBE_QPTC(i));
		uint32_t delta_qprdc = DWC_READ_REG(hw, IXGBE_QPRDC(i));

		delta_gprc += delta_qprc;

		hw_stats->qprc[i] += delta_qprc;
		hw_stats->qptc[i] += delta_qptc;

		hw_stats->qbrc[i] += DWC_READ_REG(hw, IXGBE_QBRC_L(i));
		hw_stats->qbrc[i] +=
		    ((uint64_t)DWC_READ_REG(hw, IXGBE_QBRC_H(i)) << 32);
		if (crc_strip == 0)
			hw_stats->qbrc[i] -= delta_qprc * ETHER_CRC_LEN;

		hw_stats->qbtc[i] += DWC_READ_REG(hw, IXGBE_QBTC_L(i));
		hw_stats->qbtc[i] +=
		    ((uint64_t)DWC_READ_REG(hw, IXGBE_QBTC_H(i)) << 32);

		hw_stats->qprdc[i] += delta_qprdc;
		*total_qprdc += hw_stats->qprdc[i];

		*total_qprc += hw_stats->qprc[i];
		*total_qbrc += hw_stats->qbrc[i];
	}
	hw_stats->mlfc += DWC_READ_REG(hw, IXGBE_MLFC);
	hw_stats->mrfc += DWC_READ_REG(hw, IXGBE_MRFC);
	hw_stats->rlec += DWC_READ_REG(hw, IXGBE_RLEC);

	/*
	 * An errata states that gprc actually counts good + missed packets:
	 * Workaround to set gprc to summated queue packet receives
	 */
	hw_stats->gprc = *total_qprc;

	if (hw->mac.type != dwc_mac_1) {
		hw_stats->gorc += DWC_READ_REG(hw, IXGBE_GORCL);
		hw_stats->gorc += ((u64)DWC_READ_REG(hw, IXGBE_GORCH) << 32);
		hw_stats->gotc += DWC_READ_REG(hw, IXGBE_GOTCL);
		hw_stats->gotc += ((u64)DWC_READ_REG(hw, IXGBE_GOTCH) << 32);
		hw_stats->tor += DWC_READ_REG(hw, IXGBE_TORL);
		hw_stats->tor += ((u64)DWC_READ_REG(hw, IXGBE_TORH) << 32);
		hw_stats->lxonrxc += DWC_READ_REG(hw, IXGBE_LXONRXCNT);
		hw_stats->lxoffrxc += DWC_READ_REG(hw, IXGBE_LXOFFRXCNT);
	} else {
		hw_stats->lxonrxc += DWC_READ_REG(hw, IXGBE_LXONRXC);
		hw_stats->lxoffrxc += DWC_READ_REG(hw, IXGBE_LXOFFRXC);
		/* 82598 only has a counter in the high register */
		hw_stats->gorc += DWC_READ_REG(hw, IXGBE_GORCH);
		hw_stats->gotc += DWC_READ_REG(hw, IXGBE_GOTCH);
		hw_stats->tor += DWC_READ_REG(hw, IXGBE_TORH);
	}
	uint64_t old_tpr = hw_stats->tpr;

	hw_stats->tpr += DWC_READ_REG(hw, IXGBE_TPR);
	hw_stats->tpt += DWC_READ_REG(hw, IXGBE_TPT);

	if (crc_strip == 0)
		hw_stats->gorc -= delta_gprc * ETHER_CRC_LEN;

	uint64_t delta_gptc = DWC_READ_REG(hw, IXGBE_GPTC);
	hw_stats->gptc += delta_gptc;
	hw_stats->gotc -= delta_gptc * ETHER_CRC_LEN;
	hw_stats->tor -= (hw_stats->tpr - old_tpr) * ETHER_CRC_LEN;

	/*
	 * Workaround: mprc hardware is incorrectly counting
	 * broadcasts, so for now we subtract those.
	 */
	bprc = DWC_READ_REG(hw, IXGBE_BPRC);
	hw_stats->bprc += bprc;
	hw_stats->mprc += DWC_READ_REG(hw, IXGBE_MPRC);
	if (hw->mac.type == dwc_mac_1)
		hw_stats->mprc -= bprc;

	hw_stats->prc64 += DWC_READ_REG(hw, IXGBE_PRC64);
	hw_stats->prc127 += DWC_READ_REG(hw, IXGBE_PRC127);
	hw_stats->prc255 += DWC_READ_REG(hw, IXGBE_PRC255);
	hw_stats->prc511 += DWC_READ_REG(hw, IXGBE_PRC511);
	hw_stats->prc1023 += DWC_READ_REG(hw, IXGBE_PRC1023);
	hw_stats->prc1522 += DWC_READ_REG(hw, IXGBE_PRC1522);

	lxon = DWC_READ_REG(hw, IXGBE_LXONTXC);
	hw_stats->lxontxc += lxon;
	lxoff = DWC_READ_REG(hw, IXGBE_LXOFFTXC);
	hw_stats->lxofftxc += lxoff;
	total = lxon + lxoff;

	hw_stats->mptc += DWC_READ_REG(hw, IXGBE_MPTC);
	hw_stats->ptc64 += DWC_READ_REG(hw, IXGBE_PTC64);
	hw_stats->gptc -= total;
	hw_stats->mptc -= total;
	hw_stats->ptc64 -= total;
	hw_stats->gotc -= total * ETHER_MIN_LEN;

	hw_stats->ruc += DWC_READ_REG(hw, IXGBE_RUC);
	hw_stats->rfc += DWC_READ_REG(hw, IXGBE_RFC);
	hw_stats->roc += DWC_READ_REG(hw, IXGBE_ROC);
	hw_stats->rjc += DWC_READ_REG(hw, IXGBE_RJC);
	hw_stats->mngprc += DWC_READ_REG(hw, IXGBE_MNGPRC);
	hw_stats->mngpdc += DWC_READ_REG(hw, IXGBE_MNGPDC);
	hw_stats->mngptc += DWC_READ_REG(hw, IXGBE_MNGPTC);
	hw_stats->ptc127 += DWC_READ_REG(hw, IXGBE_PTC127);
	hw_stats->ptc255 += DWC_READ_REG(hw, IXGBE_PTC255);
	hw_stats->ptc511 += DWC_READ_REG(hw, IXGBE_PTC511);
	hw_stats->ptc1023 += DWC_READ_REG(hw, IXGBE_PTC1023);
	hw_stats->ptc1522 += DWC_READ_REG(hw, IXGBE_PTC1522);
	hw_stats->bptc += DWC_READ_REG(hw, IXGBE_BPTC);
	hw_stats->xec += DWC_READ_REG(hw, IXGBE_XEC);
	hw_stats->fccrc += DWC_READ_REG(hw, IXGBE_FCCRC);
	hw_stats->fclast += DWC_READ_REG(hw, IXGBE_FCLAST);
	/* Only read FCOE on 82599 */
	if (hw->mac.type != dwc_mac_1) {
		hw_stats->fcoerpdc += DWC_READ_REG(hw, IXGBE_FCOERPDC);
		hw_stats->fcoeprc += DWC_READ_REG(hw, IXGBE_FCOEPRC);
		hw_stats->fcoeptc += DWC_READ_REG(hw, IXGBE_FCOEPTC);
		hw_stats->fcoedwrc += DWC_READ_REG(hw, IXGBE_FCOEDWRC);
		hw_stats->fcoedwtc += DWC_READ_REG(hw, IXGBE_FCOEDWTC);
	}

	/* Flow Director Stats registers */
	if (hw->mac.type != dwc_mac_1) {
		hw_stats->fdirmatch += DWC_READ_REG(hw, IXGBE_FDIRMATCH);
		hw_stats->fdirmiss += DWC_READ_REG(hw, IXGBE_FDIRMISS);
		hw_stats->fdirustat_add += DWC_READ_REG(hw,
					IXGBE_FDIRUSTAT) & 0xFFFF;
		hw_stats->fdirustat_remove += (DWC_READ_REG(hw,
					IXGBE_FDIRUSTAT) >> 16) & 0xFFFF;
		hw_stats->fdirfstat_fadd += DWC_READ_REG(hw,
					IXGBE_FDIRFSTAT) & 0xFFFF;
		hw_stats->fdirfstat_fremove += (DWC_READ_REG(hw,
					IXGBE_FDIRFSTAT) >> 16) & 0xFFFF;
	}
	/* MACsec Stats registers */
	macsec_stats->out_pkts_untagged += DWC_READ_REG(hw, IXGBE_LSECTXUT);
	macsec_stats->out_pkts_encrypted +=
		DWC_READ_REG(hw, IXGBE_LSECTXPKTE);
	macsec_stats->out_pkts_protected +=
		DWC_READ_REG(hw, IXGBE_LSECTXPKTP);
	macsec_stats->out_octets_encrypted +=
		DWC_READ_REG(hw, IXGBE_LSECTXOCTE);
	macsec_stats->out_octets_protected +=
		DWC_READ_REG(hw, IXGBE_LSECTXOCTP);
	macsec_stats->in_pkts_untagged += DWC_READ_REG(hw, IXGBE_LSECRXUT);
	macsec_stats->in_pkts_badtag += DWC_READ_REG(hw, IXGBE_LSECRXBAD);
	macsec_stats->in_pkts_nosci += DWC_READ_REG(hw, IXGBE_LSECRXNOSCI);
	macsec_stats->in_pkts_unknownsci +=
		DWC_READ_REG(hw, IXGBE_LSECRXUNSCI);
	macsec_stats->in_octets_decrypted +=
		DWC_READ_REG(hw, IXGBE_LSECRXOCTD);
	macsec_stats->in_octets_validated +=
		DWC_READ_REG(hw, IXGBE_LSECRXOCTV);
	macsec_stats->in_pkts_unchecked += DWC_READ_REG(hw, IXGBE_LSECRXUNCH);
	macsec_stats->in_pkts_delayed += DWC_READ_REG(hw, IXGBE_LSECRXDELAY);
	macsec_stats->in_pkts_late += DWC_READ_REG(hw, IXGBE_LSECRXLATE);
	for (i = 0; i < 2; i++) {
		macsec_stats->in_pkts_ok +=
			DWC_READ_REG(hw, IXGBE_LSECRXOK(i));
		macsec_stats->in_pkts_invalid +=
			DWC_READ_REG(hw, IXGBE_LSECRXINV(i));
		macsec_stats->in_pkts_notvalid +=
			DWC_READ_REG(hw, IXGBE_LSECRXNV(i));
	}
	macsec_stats->in_pkts_unusedsa += DWC_READ_REG(hw, IXGBE_LSECRXUNSA);
	macsec_stats->in_pkts_notusingsa +=
		DWC_READ_REG(hw, IXGBE_LSECRXNUSA);

#endif //add by zs
}

/*
 * This function is based on ixgbe_update_stats_counters() in ixgbe/ixgbe.c
 */
static int
dwc_dev_stats_get(struct rte_eth_dev *dev, struct rte_eth_stats *stats)
{

	struct mac_pdata *pdata =
		DWC_DEV_PRIVATE_TO_PDATA(dev->data->dev_private);
    int ret;
    struct mac_stats *pstats = &pdata->stats;
    pdata->hw_ops.read_mmc_stats(pdata);

    stats->ipackets = pstats->rxframecount_gb;
    stats->ibytes = pstats->rxoctetcount_gb;
    stats->ierrors = pstats->rxframecount_gb -
               pstats->rxbroadcastframes_g -
               pstats->rxmulticastframes_g -
               pstats->rxunicastframes_g;

    stats->opackets = pstats->txframecount_gb;
    stats->obytes = pstats->txoctetcount_gb;
    stats->oerrors = pstats->txframecount_gb - pstats->txframecount_g;

#if 0		//add by zs
	struct dwc_hw *hw =
			DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	struct mac_stats *hw_stats =
			DWC_DEV_PRIVATE_TO_STATS(dev->data->dev_private);
	
/*
	struct dwc_macsec_stats *macsec_stats =
			DWC_DEV_PRIVATE_TO_MACSEC_STATS(
				dev->data->dev_private);
*/

	uint64_t total_missed_rx, total_qbrc, total_qprc, total_qprdc;
	unsigned i;

	total_missed_rx = 0;
	total_qbrc = 0;
	total_qprc = 0;
	total_qprdc = 0;


	dwc_read_stats_registers(hw, hw_stats, macsec_stats, &total_missed_rx,
			&total_qbrc, &total_qprc, &total_qprdc);

	if (stats == NULL)
		return -EINVAL;

	/* Fill out the rte_eth_stats statistics structure */
	stats->ipackets = total_qprc;
	stats->ibytes = total_qbrc;
	stats->opackets = hw_stats->gptc;
	stats->obytes = hw_stats->gotc;

	for (i = 0; i < IXGBE_QUEUE_STAT_COUNTERS; i++) {
		stats->q_ipackets[i] = hw_stats->qprc[i];
		stats->q_opackets[i] = hw_stats->qptc[i];
		stats->q_ibytes[i] = hw_stats->qbrc[i];
		stats->q_obytes[i] = hw_stats->qbtc[i];
		stats->q_errors[i] = hw_stats->qprdc[i];
	}

	/* Rx Errors */
	stats->imissed  = total_missed_rx;
	stats->ierrors  = hw_stats->crcerrs +
			  hw_stats->mspdc +
			  hw_stats->rlec +
			  hw_stats->ruc +
			  hw_stats->roc +
			  hw_stats->illerrc +
			  hw_stats->errbc +
			  hw_stats->rfc +
			  hw_stats->fccrc +
			  hw_stats->fclast;

	/* Tx Errors */
	stats->oerrors  = 0;

#endif 		//add by zs

	return 0;
}

static void
dwc_dev_stats_reset(struct rte_eth_dev *dev)
{
	struct mac_stats *stats =
			DWC_DEV_PRIVATE_TO_STATS(dev->data->dev_private);

	/* HW registers are cleared on read */
	dwc_dev_stats_get(dev, NULL);

	/* Reset software totals */
	memset(stats, 0, sizeof(*stats));
}

#if 0  //add by zs, 20200224

/* This function calculates the number of xstats based on the current config */
static unsigned
dwc_xstats_calc_num(void) {
	return DWC_NB_HW_STATS + DWC_NB_MACSEC_STATS +
		(DWC_NB_RXQ_PRIO_STATS * DWC_NB_RXQ_PRIO_VALUES) +
		(DWC_NB_TXQ_PRIO_STATS * DWC_NB_TXQ_PRIO_VALUES);
}

static int dwc_dev_xstats_get_names(__rte_unused struct rte_eth_dev *dev,
	struct rte_eth_xstat_name *xstats_names, __rte_unused unsigned int size)
{
	const unsigned cnt_stats = dwc_xstats_calc_num();
	unsigned stat, i, count;

	if (xstats_names != NULL) {
		count = 0;

		/* Note: limit >= cnt_stats checked upstream
		 * in rte_eth_xstats_names()
		 */

		/* Extended stats from dwc_hw_stats */
		for (i = 0; i < DWC_NB_HW_STATS; i++) {
			snprintf(xstats_names[count].name,
				sizeof(xstats_names[count].name),
				"%s",
				rte_dwc_stats_strings[i].name);
			count++;
		}

		/* MACsec Stats */
		for (i = 0; i < DWC_NB_MACSEC_STATS; i++) {
			snprintf(xstats_names[count].name,
				sizeof(xstats_names[count].name),
				"%s",
				rte_dwc_macsec_strings[i].name);
			count++;
		}

		/* RX Priority Stats */
		for (stat = 0; stat < DWC_NB_RXQ_PRIO_STATS; stat++) {
			for (i = 0; i < DWC_NB_RXQ_PRIO_VALUES; i++) {
				snprintf(xstats_names[count].name,
					sizeof(xstats_names[count].name),
					"rx_priority%u_%s", i,
					rte_dwc_rxq_strings[stat].name);
				count++;
			}
		}

		/* TX Priority Stats */
		for (stat = 0; stat < DWC_NB_TXQ_PRIO_STATS; stat++) {
			for (i = 0; i < DWC_NB_TXQ_PRIO_VALUES; i++) {
				snprintf(xstats_names[count].name,
					sizeof(xstats_names[count].name),
					"tx_priority%u_%s", i,
					rte_dwc_txq_strings[stat].name);
				count++;
			}
		}
	}
	return cnt_stats;
}

static int dwc_dev_xstats_get_names_by_id(
	struct rte_eth_dev *dev,
	struct rte_eth_xstat_name *xstats_names,
	const uint64_t *ids,
	unsigned int limit)
{
	if (!ids) {
		const unsigned int cnt_stats = dwc_xstats_calc_num();
		unsigned int stat, i, count;

		if (xstats_names != NULL) {
			count = 0;

			/* Note: limit >= cnt_stats checked upstream
			 * in rte_eth_xstats_names()
			 */

			/* Extended stats from dwc_hw_stats */
			for (i = 0; i < DWC_NB_HW_STATS; i++) {
				snprintf(xstats_names[count].name,
					sizeof(xstats_names[count].name),
					"%s",
					rte_dwc_stats_strings[i].name);
				count++;
			}

			/* MACsec Stats */
			for (i = 0; i < DWC_NB_MACSEC_STATS; i++) {
				snprintf(xstats_names[count].name,
					sizeof(xstats_names[count].name),
					"%s",
					rte_dwc_macsec_strings[i].name);
				count++;
			}

			/* RX Priority Stats */
			for (stat = 0; stat < DWC_NB_RXQ_PRIO_STATS; stat++) {
				for (i = 0; i < DWC_NB_RXQ_PRIO_VALUES; i++) {
					snprintf(xstats_names[count].name,
					    sizeof(xstats_names[count].name),
					    "rx_priority%u_%s", i,
					    rte_dwc_rxq_strings[stat].name);
					count++;
				}
			}

			/* TX Priority Stats */
			for (stat = 0; stat < DWC_NB_TXQ_PRIO_STATS; stat++) {
				for (i = 0; i < DWC_NB_TXQ_PRIO_VALUES; i++) {
					snprintf(xstats_names[count].name,
					    sizeof(xstats_names[count].name),
					    "tx_priority%u_%s", i,
					    rte_dwc_txq_strings[stat].name);
					count++;
				}
			}
		}
		return cnt_stats;
	}

	uint16_t i;
	uint16_t size = dwc_xstats_calc_num();
	struct rte_eth_xstat_name xstats_names_copy[size];

	dwc_dev_xstats_get_names_by_id(dev, xstats_names_copy, NULL,
			size);

	for (i = 0; i < limit; i++) {
		if (ids[i] >= size) {
			PMD_INIT_LOG(ERR, "id value isn't valid");
			return -1;
		}
		strcpy(xstats_names[i].name,
				xstats_names_copy[ids[i]].name);
	}
	return limit;
}

static int
dwc_dev_xstats_get(struct rte_eth_dev *dev, struct rte_eth_xstat *xstats,
					 unsigned n)
{
	struct dwc_hw *hw =
			DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	struct dwc_hw_stats *hw_stats =
			DWC_DEV_PRIVATE_TO_STATS(dev->data->dev_private);
	struct dwc_macsec_stats *macsec_stats =
			DWC_DEV_PRIVATE_TO_MACSEC_STATS(
				dev->data->dev_private);
	uint64_t total_missed_rx, total_qbrc, total_qprc, total_qprdc;
	unsigned i, stat, count = 0;

	count = dwc_xstats_calc_num();

	if (n < count)
		return count;

	total_missed_rx = 0;
	total_qbrc = 0;
	total_qprc = 0;
	total_qprdc = 0;

	dwc_read_stats_registers(hw, hw_stats, macsec_stats, &total_missed_rx,
			&total_qbrc, &total_qprc, &total_qprdc);

	/* If this is a reset xstats is NULL, and we have cleared the
	 * registers by reading them.
	 */
	if (!xstats)
		return 0;

	/* Extended stats from dwc_hw_stats */
	count = 0;
	for (i = 0; i < DWC_NB_HW_STATS; i++) {
		xstats[count].value = *(uint64_t *)(((char *)hw_stats) +
				rte_dwc_stats_strings[i].offset);
		xstats[count].id = count;
		count++;
	}

	/* MACsec Stats */
	for (i = 0; i < DWC_NB_MACSEC_STATS; i++) {
		xstats[count].value = *(uint64_t *)(((char *)macsec_stats) +
				rte_dwc_macsec_strings[i].offset);
		xstats[count].id = count;
		count++;
	}

	/* RX Priority Stats */
	for (stat = 0; stat < DWC_NB_RXQ_PRIO_STATS; stat++) {
		for (i = 0; i < DWC_NB_RXQ_PRIO_VALUES; i++) {
			xstats[count].value = *(uint64_t *)(((char *)hw_stats) +
					rte_dwc_rxq_strings[stat].offset +
					(sizeof(uint64_t) * i));
			xstats[count].id = count;
			count++;
		}
	}

	/* TX Priority Stats */
	for (stat = 0; stat < DWC_NB_TXQ_PRIO_STATS; stat++) {
		for (i = 0; i < DWC_NB_TXQ_PRIO_VALUES; i++) {
			xstats[count].value = *(uint64_t *)(((char *)hw_stats) +
					rte_dwc_txq_strings[stat].offset +
					(sizeof(uint64_t) * i));
			xstats[count].id = count;
			count++;
		}
	}
	return count;
}

static int
dwc_dev_xstats_get_by_id(struct rte_eth_dev *dev, const uint64_t *ids,
		uint64_t *values, unsigned int n)
{
	if (!ids) {
		struct dwc_hw *hw =
				DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
		struct dwc_hw_stats *hw_stats =
				DWC_DEV_PRIVATE_TO_STATS(
						dev->data->dev_private);
		struct dwc_macsec_stats *macsec_stats =
				DWC_DEV_PRIVATE_TO_MACSEC_STATS(
					dev->data->dev_private);
		uint64_t total_missed_rx, total_qbrc, total_qprc, total_qprdc;
		unsigned int i, stat, count = 0;

		count = dwc_xstats_calc_num();

		if (!ids && n < count)
			return count;

		total_missed_rx = 0;
		total_qbrc = 0;
		total_qprc = 0;
		total_qprdc = 0;

		dwc_read_stats_registers(hw, hw_stats, macsec_stats,
				&total_missed_rx, &total_qbrc, &total_qprc,
				&total_qprdc);

		/* If this is a reset xstats is NULL, and we have cleared the
		 * registers by reading them.
		 */
		if (!ids && !values)
			return 0;

		/* Extended stats from dwc_hw_stats */
		count = 0;
		for (i = 0; i < DWC_NB_HW_STATS; i++) {
			values[count] = *(uint64_t *)(((char *)hw_stats) +
					rte_dwc_stats_strings[i].offset);
			count++;
		}

		/* MACsec Stats */
		for (i = 0; i < DWC_NB_MACSEC_STATS; i++) {
			values[count] = *(uint64_t *)(((char *)macsec_stats) +
					rte_dwc_macsec_strings[i].offset);
			count++;
		}

		/* RX Priority Stats */
		for (stat = 0; stat < DWC_NB_RXQ_PRIO_STATS; stat++) {
			for (i = 0; i < DWC_NB_RXQ_PRIO_VALUES; i++) {
				values[count] =
					*(uint64_t *)(((char *)hw_stats) +
					rte_dwc_rxq_strings[stat].offset +
					(sizeof(uint64_t) * i));
				count++;
			}
		}

		/* TX Priority Stats */
		for (stat = 0; stat < DWC_NB_TXQ_PRIO_STATS; stat++) {
			for (i = 0; i < DWC_NB_TXQ_PRIO_VALUES; i++) {
				values[count] =
					*(uint64_t *)(((char *)hw_stats) +
					rte_dwc_txq_strings[stat].offset +
					(sizeof(uint64_t) * i));
				count++;
			}
		}
		return count;
	}

	uint16_t i;
	uint16_t size = dwc_xstats_calc_num();
	uint64_t values_copy[size];

	dwc_dev_xstats_get_by_id(dev, NULL, values_copy, size);

	for (i = 0; i < n; i++) {
		if (ids[i] >= size) {
			PMD_INIT_LOG(ERR, "id value isn't valid");
			return -1;
		}
		values[i] = values_copy[ids[i]];
	}
	return n;
}

static void
dwc_dev_xstats_reset(struct rte_eth_dev *dev)
{
	struct dwc_hw_stats *stats =
			DWC_DEV_PRIVATE_TO_STATS(dev->data->dev_private);
	struct dwc_macsec_stats *macsec_stats =
			DWC_DEV_PRIVATE_TO_MACSEC_STATS(
				dev->data->dev_private);

	unsigned count = dwc_xstats_calc_num();

	/* HW registers are cleared on read */
	dwc_dev_xstats_get(dev, NULL, count);

	/* Reset software totals */
	memset(stats, 0, sizeof(*stats));
	memset(macsec_stats, 0, sizeof(*macsec_stats));
}

static int
dwc_fw_version_get(struct rte_eth_dev *dev, char *fw_version, size_t fw_size)
{
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	u16 eeprom_verh, eeprom_verl;
	u32 etrack_id;
	int ret;

	ixgbe_read_eeprom(hw, 0x2e, &eeprom_verh);
	ixgbe_read_eeprom(hw, 0x2d, &eeprom_verl);

	etrack_id = (eeprom_verh << 16) | eeprom_verl;
	ret = snprintf(fw_version, fw_size, "0x%08x", etrack_id);

	ret += 1; /* add the size of '\0' */
	if (fw_size < (u32)ret)
		return ret;
	else
		return 0;
}

#endif  //end add by zs, 20200224

static void
dwc_dev_info_get(struct rte_eth_dev *dev, struct rte_eth_dev_info *dev_info)
{
	struct rte_pci_device *pci_dev = RTE_ETH_DEV_TO_PCI(dev);
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	struct rte_eth_conf *dev_conf = &dev->data->dev_conf;

	dev_info->max_rx_queues = (uint16_t)hw->mac.max_rx_queues;
	dev_info->max_tx_queues = (uint16_t)hw->mac.max_tx_queues;
	
#if 0 //end add by zs, 20200224
	if (RTE_ETH_DEV_SRIOV(dev).active == 0) {
		/*
		 * When DCB/VT is off, maximum number of queues changes,
		 * except for 82598EB, which remains constant.
		 */
		if (dev_conf->txmode.mq_mode == ETH_MQ_TX_NONE &&
				hw->mac.type != dwc_mac_1)
			dev_info->max_tx_queues = IXGBE_NONE_MODE_TX_NB_QUEUES;
	}
#endif //end add by zs, 20200224

	dev_info->min_rx_bufsize = (ETH_FRAME_LEN + ETH_FCS_LEN + VLAN_HLEN); 
	dev_info->max_rx_pktlen = MAC_JUMBO_PACKET_MTU+ETH_FCS_LEN+ETH_HLEN;
	dev_info->max_mac_addrs = hw->mac.num_rar_entries;
	dev_info->max_hash_mac_addrs = DWC_VMDQ_NUM_UC_MAC;
	dev_info->max_vfs = pci_dev->max_vfs;
	if (hw->mac.type == dwc_mac_1)
		dev_info->max_vmdq_pools = ETH_16_POOLS;
	else
		dev_info->max_vmdq_pools = ETH_64_POOLS;
	dev_info->vmdq_queue_num = dev_info->max_rx_queues;
	dev_info->rx_queue_offload_capa = dwc_get_rx_queue_offloads(dev);
	dev_info->rx_offload_capa = (dwc_get_rx_port_offloads(dev) |
				     dev_info->rx_queue_offload_capa);
	dev_info->tx_queue_offload_capa = dwc_get_tx_queue_offloads(dev);
	dev_info->tx_offload_capa = dwc_get_tx_port_offloads(dev);

	dev_info->default_rxconf = (struct rte_eth_rxconf) {
		.rx_thresh = {
			.pthresh = DWC_DEFAULT_RX_PTHRESH,
			.hthresh = DWC_DEFAULT_RX_HTHRESH,
			.wthresh = DWC_DEFAULT_RX_WTHRESH,
		},
		.rx_free_thresh = DWC_DEFAULT_RX_FREE_THRESH,
		.rx_drop_en = 0,
		.offloads = 0,
	};

	dev_info->default_txconf = (struct rte_eth_txconf) {
		.tx_thresh = {
			.pthresh = DWC_DEFAULT_TX_PTHRESH,
			.hthresh = DWC_DEFAULT_TX_HTHRESH,
			.wthresh = DWC_DEFAULT_TX_WTHRESH,
		},
		.tx_free_thresh = DWC_DEFAULT_TX_FREE_THRESH,
		.tx_rs_thresh = DWC_DEFAULT_TX_RSBIT_THRESH,
		.offloads = 0,
	};

	dev_info->rx_desc_lim = rx_desc_lim;
	dev_info->tx_desc_lim = tx_desc_lim;

	dev_info->hash_key_size = DWC_HKEY_MAX_INDEX * sizeof(uint32_t);
	dev_info->reta_size = dwc_reta_size_get(hw->mac.type);
	dev_info->flow_type_rss_offloads = DWC_RSS_OFFLOAD_ALL;

	//dev_info->speed_capa = ETH_LINK_SPEED_1G | ETH_LINK_SPEED_10G;
	dev_info->speed_capa = ETH_LINK_SPEED_1G | ETH_LINK_SPEED_10G | ETH_LINK_SPEED_25G
		| ETH_LINK_SPEED_50G | ETH_LINK_SPEED_100G;

	/* Driver-preferred Rx/Tx parameters */
	dev_info->default_rxportconf.burst_size = 32;
	dev_info->default_txportconf.burst_size = 32;
	dev_info->default_rxportconf.nb_queues = 1;
	dev_info->default_txportconf.nb_queues = 1;
	dev_info->default_rxportconf.ring_size = 256;
	dev_info->default_txportconf.ring_size = 256;
}

static const uint32_t *
dwc_dev_supported_ptypes_get(struct rte_eth_dev *dev)
{
	static const uint32_t ptypes[] = {
		/* For non-vec functions,
		 * refers to ixgbe_rxd_pkt_info_to_pkt_type();
		 * for vec functions,
		 * refers to _recv_raw_pkts_vec().
		 */
		RTE_PTYPE_L2_ETHER,
		RTE_PTYPE_L3_IPV4,
		RTE_PTYPE_L3_IPV4_EXT,
		RTE_PTYPE_L3_IPV6,
		RTE_PTYPE_L3_IPV6_EXT,
		RTE_PTYPE_L4_SCTP,
		RTE_PTYPE_L4_TCP,
		RTE_PTYPE_L4_UDP,
		RTE_PTYPE_TUNNEL_IP,
		RTE_PTYPE_INNER_L3_IPV6,
		RTE_PTYPE_INNER_L3_IPV6_EXT,
		RTE_PTYPE_INNER_L4_TCP,
		RTE_PTYPE_INNER_L4_UDP,
		RTE_PTYPE_UNKNOWN
	};

	if (dev->rx_pkt_burst == dwc_recv_pkts ||
	    dev->rx_pkt_burst == dwc_recv_pkts_lro_single_alloc ||
	    dev->rx_pkt_burst == dwc_recv_pkts_lro_bulk_alloc ||
	    dev->rx_pkt_burst == dwc_recv_pkts_bulk_alloc)
		return ptypes;

#if defined(RTE_ARCH_X86)
	if (dev->rx_pkt_burst == dwc_recv_pkts_vec ||
	    dev->rx_pkt_burst == dwc_recv_scattered_pkts_vec)
		return ptypes;
#endif
	return NULL;
}

static void
dwcvf_dev_info_get(struct rte_eth_dev *dev,
		     struct rte_eth_dev_info *dev_info)
{
	struct rte_pci_device *pci_dev = RTE_ETH_DEV_TO_PCI(dev);
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);

	dev_info->max_rx_queues = (uint16_t)hw->mac.max_rx_queues;
	dev_info->max_tx_queues = (uint16_t)hw->mac.max_tx_queues;
	dev_info->min_rx_bufsize = 1024; /* cf BSIZEPACKET in SRRCTL reg */
	dev_info->max_rx_pktlen = 9728; /* includes CRC, cf MAXFRS reg */
	dev_info->max_mac_addrs = hw->mac.num_rar_entries;
	dev_info->max_hash_mac_addrs = DWC_VMDQ_NUM_UC_MAC;
	dev_info->max_vfs = pci_dev->max_vfs;
	/*if (hw->mac.type == dwc_mac_1)
		dev_info->max_vmdq_pools = ETH_16_POOLS;
	else
		dev_info->max_vmdq_pools = ETH_64_POOLS; */
	dev_info->rx_queue_offload_capa = dwc_get_rx_queue_offloads(dev);
	dev_info->rx_offload_capa = (dwc_get_rx_port_offloads(dev) |
				     dev_info->rx_queue_offload_capa);
	dev_info->tx_queue_offload_capa = dwc_get_tx_queue_offloads(dev);
	dev_info->tx_offload_capa = dwc_get_tx_port_offloads(dev);

	dev_info->default_rxconf = (struct rte_eth_rxconf) {
		.rx_thresh = {
			.pthresh = DWC_DEFAULT_RX_PTHRESH,
			.hthresh = DWC_DEFAULT_RX_HTHRESH,
			.wthresh = DWC_DEFAULT_RX_WTHRESH,
		},
		.rx_free_thresh = DWC_DEFAULT_RX_FREE_THRESH,
		.rx_drop_en = 0,
		.offloads = 0,
	};

	dev_info->default_txconf = (struct rte_eth_txconf) {
		.tx_thresh = {
			.pthresh = DWC_DEFAULT_TX_PTHRESH,
			.hthresh = DWC_DEFAULT_TX_HTHRESH,
			.wthresh = DWC_DEFAULT_TX_WTHRESH,
		},
		.tx_free_thresh = DWC_DEFAULT_TX_FREE_THRESH,
		.tx_rs_thresh = DWC_DEFAULT_TX_RSBIT_THRESH,
		.offloads = 0,
	};

	dev_info->rx_desc_lim = rx_desc_lim;
	dev_info->tx_desc_lim = tx_desc_lim;
}

static int
dwcvf_check_link(struct dwc_hw *hw, dwc_link_speed *speed,
		   int *link_up, int wait_to_complete)
{
	struct dwc_mbx_info *mbx = &hw->mbx;
	struct dwc_mac_info *mac = &hw->mac;
	uint32_t links_reg, in_msg;
	int ret_val = 0;

#if 0 //add by zs

	/* If we were hit with a reset drop the link */
	if (!mbx->ops.check_for_rst(hw, 0) || !mbx->timeout)
		mac->get_link_status = true;

	if (!mac->get_link_status)
		goto out;

	/* if link status is down no point in checking to see if pf is up */
	links_reg = DWC_READ_REG(hw, IXGBE_VFLINKS);
	if (!(links_reg & IXGBE_LINKS_UP))
		goto out;

	/* for SFP+ modules and DA cables on 82599 it can take up to 500usecs
	 * before the link status is correct
	 */
	if (mac->type == ixgbe_mac_82599_vf && wait_to_complete) {
		int i;

		for (i = 0; i < 5; i++) {
			rte_delay_us(100);
			links_reg = DWC_READ_REG(hw, IXGBE_VFLINKS);

			if (!(links_reg & IXGBE_LINKS_UP))
				goto out;
		}
	}

	switch (links_reg & IXGBE_LINKS_SPEED_82599) {
	case IXGBE_LINKS_SPEED_10G_82599:
		*speed = DWC_LINK_SPEED_10GB_FULL;
		if (hw->mac.type >= ixgbe_mac_X550) {
			if (links_reg & IXGBE_LINKS_SPEED_NON_STD)
				*speed = DWC_LINK_SPEED_2_5GB_FULL;
		}
		break;
	case IXGBE_LINKS_SPEED_1G_82599:
		*speed = DWC_LINK_SPEED_1GB_FULL;
		break;
	case IXGBE_LINKS_SPEED_100_82599:
		*speed = DWC_LINK_SPEED_100_FULL;
		if (hw->mac.type == ixgbe_mac_X550) {
			if (links_reg & IXGBE_LINKS_SPEED_NON_STD)
				*speed = DWC_LINK_SPEED_5GB_FULL;
		}
		break;
	case IXGBE_LINKS_SPEED_10_X550EM_A:
		*speed = DWC_LINK_SPEED_UNKNOWN;
		/* Since Reserved in older MAC's */
		if (hw->mac.type >= ixgbe_mac_X550)
			*speed = DWC_LINK_SPEED_10_FULL;
		break;
	default:
		*speed = DWC_LINK_SPEED_UNKNOWN;
	}

	/* if the read failed it could just be a mailbox collision, best wait
	 * until we are called again and don't report an error
	 */
	if (mbx->ops.read(hw, &in_msg, 1, 0))
		goto out;

	if (!(in_msg & IXGBE_VT_MSGTYPE_CTS)) {
		/* msg is not CTS and is NACK we must have lost CTS status */
		if (in_msg & IXGBE_VT_MSGTYPE_NACK)
			mac->get_link_status = false;
		goto out;
	}

	/* the pf is talking, if we timed out in the past we reinit */
	if (!mbx->timeout) {
		ret_val = -1;
		goto out;
	}

	/* if we passed all the tests above then the link is up and we no
	 * longer need to check for link
	 */
	mac->get_link_status = false;

out:
	*link_up = !mac->get_link_status;

#endif //add by zs

	return ret_val;
}

static void
dwc_dev_setup_link_alarm_handler(void *param)
{
	struct rte_eth_dev *dev = (struct rte_eth_dev *)param;
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	struct dwc_interrupt *intr =
		DWC_DEV_PRIVATE_TO_INTR(dev->data->dev_private);
	u32 speed;
	bool autoneg = false;

	speed = hw->phy.autoneg_advertised;
	if (!speed)
		dwc_get_link_capabilities(hw, &speed, &autoneg);

	dwc_setup_link(hw, speed, true);

	intr->flags &= ~DWC_FLAG_NEED_LINK_CONFIG;
}

/* return 0 means link status changed, -1 means not changed */
int
dwc_dev_link_update_share(struct rte_eth_dev *dev,
			    int wait_to_complete, int vf)
{
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	struct rte_eth_link link;
	ixgbe_link_speed link_speed = DWC_LINK_SPEED_UNKNOWN;
	struct ixgbe_interrupt *intr =
		DWC_DEV_PRIVATE_TO_INTR(dev->data->dev_private);
	int link_up;
	int diag;
	int wait = 1;

	memset(&link, 0, sizeof(link));
	link.link_status = ETH_LINK_DOWN;
	link.link_speed = ETH_SPEED_NUM_NONE;
	link.link_duplex = ETH_LINK_HALF_DUPLEX;
	link.link_autoneg = ETH_LINK_AUTONEG;

	hw->mac.get_link_status = true;

	if (intr->flags & DWC_FLAG_NEED_LINK_CONFIG)
		return rte_eth_linkstatus_set(dev, &link);

	/* check if it needs to wait to complete, if lsc interrupt is enabled */
	if (wait_to_complete == 0 || dev->data->dev_conf.intr_conf.lsc != 0)
		wait = 0;

	if (vf)
		diag = dwcvf_check_link(hw, &link_speed, &link_up, wait);
	else
		diag = dwc_check_link(hw, &link_speed, &link_up, wait);

	if (diag != 0) {
		link.link_speed = ETH_SPEED_NUM_100M;
		link.link_duplex = ETH_LINK_FULL_DUPLEX;
		return rte_eth_linkstatus_set(dev, &link);
	}

#if 0 	//add by zs, 20200224

	if (link_up == 0) {
		if (ixgbe_get_media_type(hw) == ixgbe_media_type_fiber) {
			intr->flags |= DWC_FLAG_NEED_LINK_CONFIG;
			rte_eal_alarm_set(10,
				dwc_dev_setup_link_alarm_handler, dev);
		}
		return rte_eth_linkstatus_set(dev, &link);
	}
	
#endif 	//end add by zs, 20200224	

	link.link_status = ETH_LINK_UP;
	link.link_duplex = ETH_LINK_FULL_DUPLEX;

	switch (link_speed) {
	default:
	case DWC_LINK_SPEED_UNKNOWN:
		link.link_duplex = ETH_LINK_FULL_DUPLEX;
		link.link_speed = ETH_SPEED_NUM_100M;
		break;

	case DWC_LINK_SPEED_100_FULL:
		link.link_speed = ETH_SPEED_NUM_100M;
		break;

	case DWC_LINK_SPEED_1GB_FULL:
		link.link_speed = ETH_SPEED_NUM_1G;
		break;

	case DWC_LINK_SPEED_2_5GB_FULL:
		link.link_speed = ETH_SPEED_NUM_2_5G;
		break;

	case DWC_LINK_SPEED_5GB_FULL:
		link.link_speed = ETH_SPEED_NUM_5G;
		break;

	case DWC_LINK_SPEED_10GB_FULL:
		link.link_speed = ETH_SPEED_NUM_10G;
		break;
	}

	return rte_eth_linkstatus_set(dev, &link);
}

static int
dwc_dev_link_update(struct rte_eth_dev *dev, int wait_to_complete)
{
	return dwc_dev_link_update_share(dev, wait_to_complete, 0);
}

static int
dwcvf_dev_link_update(struct rte_eth_dev *dev, int wait_to_complete)
{
	return dwc_dev_link_update_share(dev, wait_to_complete, 1);
}

static void
dwc_dev_promiscuous_enable(struct rte_eth_dev *dev)
{
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	uint32_t fctrl;

	fctrl = DWC_READ_REG(hw, DWC_FCTRL);
	fctrl |= (DWC_FCTRL_UPE | DWC_FCTRL_MPE);
	DWC_WRITE_REG(hw, DWC_FCTRL, fctrl);
}

static void
dwc_dev_promiscuous_disable(struct rte_eth_dev *dev)
{
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	uint32_t fctrl;

	fctrl = DWC_READ_REG(hw, DWC_FCTRL);
	fctrl &= (~DWC_FCTRL_UPE);
	if (dev->data->all_multicast == 1)
		fctrl |= DWC_FCTRL_MPE;
	else
		fctrl &= (~DWC_FCTRL_MPE);
	DWC_WRITE_REG(hw, DWC_FCTRL, fctrl);
}

static void
dwc_dev_allmulticast_enable(struct rte_eth_dev *dev)
{
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	uint32_t fctrl;

	fctrl = DWC_READ_REG(hw, DWC_FCTRL);
	fctrl |= DWC_FCTRL_MPE;
	DWC_WRITE_REG(hw, DWC_FCTRL, fctrl);
}

static void
dwc_dev_allmulticast_disable(struct rte_eth_dev *dev)
{
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	uint32_t fctrl;

	if (dev->data->promiscuous == 1)
		return; /* must remain in all_multicast mode */

	fctrl = DWC_READ_REG(hw, DWC_FCTRL);
	fctrl &= (~DWC_FCTRL_MPE);
	DWC_WRITE_REG(hw, DWC_FCTRL, fctrl);
}

/**
 * It clears the interrupt causes and enables the interrupt.
 * It will be called once only during nic initialized.
 *
 * @param dev
 *  Pointer to struct rte_eth_dev.
 * @param on
 *  Enable or Disable.
 *
 * @return
 *  - On success, zero.
 *  - On failure, a negative value.
 */
static int
dwc_dev_lsc_interrupt_setup(struct rte_eth_dev *dev, uint8_t on)
{
	struct ixgbe_interrupt *intr =
		DWC_DEV_PRIVATE_TO_INTR(dev->data->dev_private);

	dwc_dev_link_status_print(dev);
	if (on)
		intr->mask |= IXGBE_EICR_LSC;
	else
		intr->mask &= ~IXGBE_EICR_LSC;

	return 0;
}

/**
 * It clears the interrupt causes and enables the interrupt.
 * It will be called once only during nic initialized.
 *
 * @param dev
 *  Pointer to struct rte_eth_dev.
 *
 * @return
 *  - On success, zero.
 *  - On failure, a negative value.
 */
static int
dwc_dev_rxq_interrupt_setup(struct rte_eth_dev *dev)
{
	struct ixgbe_interrupt *intr =
		DWC_DEV_PRIVATE_TO_INTR(dev->data->dev_private);

	intr->mask |= IXGBE_EICR_RTX_QUEUE;

	return 0;
}

/**
 * It clears the interrupt causes and enables the interrupt.
 * It will be called once only during nic initialized.
 *
 * @param dev
 *  Pointer to struct rte_eth_dev.
 *
 * @return
 *  - On success, zero.
 *  - On failure, a negative value.
 */
static int
dwc_dev_macsec_interrupt_setup(struct rte_eth_dev *dev)
{
	struct ixgbe_interrupt *intr =
		DWC_DEV_PRIVATE_TO_INTR(dev->data->dev_private);

	intr->mask |= IXGBE_EICR_LINKSEC;

	return 0;
}

/*
 * It reads ICR and sets flag (IXGBE_EICR_LSC) for the link_update.
 *
 * @param dev
 *  Pointer to struct rte_eth_dev.
 *
 * @return
 *  - On success, zero.
 *  - On failure, a negative value.
 */
static int
dwc_dev_interrupt_get_status(struct rte_eth_dev *dev)
{
	uint32_t eicr;
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	struct dwc_interrupt *intr =
		DWC_DEV_PRIVATE_TO_INTR(dev->data->dev_private);

	/* clear all cause mask */
	dwc_disable_intr(hw);

#if 0	//add by zs

	/* read-on-clear nic registers here */
	eicr = DWC_READ_REG(hw, IXGBE_EICR);
	PMD_DRV_LOG(DEBUG, "eicr %x", eicr);

	intr->flags = 0;


	/* set flag for async link update */
	if (eicr & IXGBE_EICR_LSC)
		intr->flags |= IXGBE_FLAG_NEED_LINK_UPDATE;

	if (eicr & IXGBE_EICR_MAILBOX)
		intr->flags |= DWC_FLAG_MAILBOX;

	if (eicr & IXGBE_EICR_LINKSEC)
		intr->flags |= IXGBE_FLAG_MACSEC;

	if (hw->mac.type ==  ixgbe_mac_X550EM_x &&
	    hw->phy.type == ixgbe_phy_x550em_ext_t &&
	    (eicr & IXGBE_EICR_GPI_SDP0_X550EM_x))
		intr->flags |= IXGBE_FLAG_PHY_INTERRUPT;

#endif	//add by zs

	return 0;
}

/**
 * It gets and then prints the link status.
 *
 * @param dev
 *  Pointer to struct rte_eth_dev.
 *
 * @return
 *  - On success, zero.
 *  - On failure, a negative value.
 */
static void
dwc_dev_link_status_print(struct rte_eth_dev *dev)
{
	struct rte_pci_device *pci_dev = RTE_ETH_DEV_TO_PCI(dev);
	struct rte_eth_link link;

	rte_eth_linkstatus_get(dev, &link);

	if (link.link_status) {
		PMD_INIT_LOG(INFO, "Port %d: Link Up - speed %u Mbps - %s",
					(int)(dev->data->port_id),
					(unsigned)link.link_speed,
			link.link_duplex == ETH_LINK_FULL_DUPLEX ?
					"full-duplex" : "half-duplex");
	} else {
		PMD_INIT_LOG(INFO, " Port %d: Link Down",
				(int)(dev->data->port_id));
	}
	PMD_INIT_LOG(DEBUG, "PCI Address: " PCI_PRI_FMT,
				pci_dev->addr.domain,
				pci_dev->addr.bus,
				pci_dev->addr.devid,
				pci_dev->addr.function);
}

/*
 * It executes link_update after knowing an interrupt occurred.
 *
 * @param dev
 *  Pointer to struct rte_eth_dev.
 *
 * @return
 *  - On success, zero.
 *  - On failure, a negative value.
 */
static int
dwc_dev_interrupt_action(struct rte_eth_dev *dev)
{
	struct dwc_interrupt *intr =
		DWC_DEV_PRIVATE_TO_INTR(dev->data->dev_private);

	PMD_DRV_LOG(DEBUG, "intr action type %d", intr->flags);

#if 0 //add by zs

	int64_t timeout;
	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);

	if (intr->flags & DWC_FLAG_MAILBOX) {
		ixgbe_pf_mbx_process(dev);
		intr->flags &= ~DWC_FLAG_MAILBOX;
	}

	if (intr->flags & IXGBE_FLAG_PHY_INTERRUPT) {
		ixgbe_handle_lasi(hw);
		intr->flags &= ~IXGBE_FLAG_PHY_INTERRUPT;
	}

	if (intr->flags & IXGBE_FLAG_NEED_LINK_UPDATE) {
		struct rte_eth_link link;

		/* get the link status before link update, for predicting later */
		rte_eth_linkstatus_get(dev, &link);

		dwc_dev_link_update(dev, 0);

		/* likely to up */
		if (!link.link_status)
			/* handle it 1 sec later, wait it being stable */
			timeout = IXGBE_LINK_UP_CHECK_TIMEOUT;
		/* likely to down */
		else
			/* handle it 4 sec later, wait it being stable */
			timeout = IXGBE_LINK_DOWN_CHECK_TIMEOUT;

		dwc_dev_link_status_print(dev);
		if (rte_eal_alarm_set(timeout * 1000,
				      ixgbe_dev_interrupt_delayed_handler, (void *)dev) < 0)
			PMD_DRV_LOG(ERR, "Error setting alarm");
		else {
			/* remember original mask */
			intr->mask_original = intr->mask;
			/* only disable lsc interrupt */
			intr->mask &= ~IXGBE_EIMS_LSC;
		}
	}

#endif //add by zs

	PMD_DRV_LOG(DEBUG, "enable intr immediately");
	dwc_enable_intr(dev);

	return 0;
}

/**
 * Interrupt handler triggered by NIC  for handling
 * specific interrupt.
 *
 * @param handle
 *  Pointer to interrupt handle.
 * @param param
 *  The address of parameter (struct rte_eth_dev *) regsitered before.
 *
 * @return
 *  void
 */
static void
dwc_dev_interrupt_handler(void *param)
{
	struct rte_eth_dev *dev = (struct rte_eth_dev *)param;

	dwc_dev_interrupt_get_status(dev);
	dwc_dev_interrupt_action(dev);
}


static bool
is_device_supported(struct rte_eth_dev *dev, struct rte_pci_driver *drv)
{
	if (strcmp(dev->device->driver->name, drv->driver.name))
		return false;

	return true;
}

bool
is_dwc_supported(struct rte_eth_dev *dev)
{
	return is_device_supported(dev, &rte_dwc_pmd);
}

static int
dwc_dev_mtu_set(struct rte_eth_dev *dev, uint16_t mtu)
{
	uint32_t hlreg0;
	uint32_t maxfrs;
	struct dwc_hw *hw;
	struct rte_eth_dev_info dev_info;
	uint32_t frame_size = mtu + ETHER_HDR_LEN + ETHER_CRC_LEN;
	struct rte_eth_dev_data *dev_data = dev->data;


	dwc_dev_info_get(dev, &dev_info);

	/* check that mtu is within the allowed range */
	if ((mtu < ETHER_MIN_MTU) || (frame_size > dev_info.max_rx_pktlen))
		return -EINVAL;

#if 0 //add by zs

	/* If device is started, refuse mtu that requires the support of
	 * scattered packets when this feature has not been enabled before.
	 */
	if (dev_data->dev_started && !dev_data->scattered_rx &&
	    (frame_size + 2 * DWC_VLAN_TAG_SIZE >
	     dev->data->min_rx_buf_size - RTE_PKTMBUF_HEADROOM)) {
		PMD_INIT_LOG(ERR, "Stop port first.");
		return -EINVAL;
	}

	hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	hlreg0 = DWC_READ_REG(hw, IXGBE_HLREG0);

	/* switch to jumbo mode if needed */
	if (frame_size > ETHER_MAX_LEN) {
		dev->data->dev_conf.rxmode.offloads |=
			DEV_RX_OFFLOAD_JUMBO_FRAME;
		hlreg0 |= IXGBE_HLREG0_JUMBOEN;
	} else {
		dev->data->dev_conf.rxmode.offloads &=
			~DEV_RX_OFFLOAD_JUMBO_FRAME;
		hlreg0 &= ~IXGBE_HLREG0_JUMBOEN;
	}
	DWC_WRITE_REG(hw, IXGBE_HLREG0, hlreg0);

	/* update max frame size */
	dev->data->dev_conf.rxmode.max_rx_pkt_len = frame_size;

	maxfrs = DWC_READ_REG(hw, IXGBE_MAXFRS);
	maxfrs &= 0x0000FFFF;
	maxfrs |= (dev->data->dev_conf.rxmode.max_rx_pkt_len << 16);
	DWC_WRITE_REG(hw, IXGBE_MAXFRS, maxfrs);

#endif  //end add by zs

	return 0;
}

/*
 * Virtual Function operations
 */
static void
dwcvf_intr_disable(struct rte_eth_dev *dev)
{
	struct dwc_interrupt *intr =
		DWC_DEV_PRIVATE_TO_INTR(dev->data->dev_private);
	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);

#if 0 //add by zs

	PMD_INIT_FUNC_TRACE();

	/* Clear interrupt mask to stop from interrupts being generated */
	DWC_WRITE_REG(hw, IXGBE_VTEIMC, IXGBE_VF_IRQ_CLEAR_MASK);

	DWC_WRITE_FLUSH(hw);

	/* Clear mask value. */
	intr->mask = 0;

#endif //add by zs

}

static void
dwcvf_intr_enable(struct rte_eth_dev *dev)
{
	struct dwc_interrupt *intr =
		DWC_DEV_PRIVATE_TO_INTR(dev->data->dev_private);
	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);

#if 0  //add by zs

	PMD_INIT_FUNC_TRACE();

	/* VF enable interrupt autoclean */
	DWC_WRITE_REG(hw, IXGBE_VTEIAM, IXGBE_VF_IRQ_ENABLE_MASK);
	DWC_WRITE_REG(hw, IXGBE_VTEIAC, IXGBE_VF_IRQ_ENABLE_MASK);
	DWC_WRITE_REG(hw, IXGBE_VTEIMS, IXGBE_VF_IRQ_ENABLE_MASK);

	DWC_WRITE_FLUSH(hw);

	/* Save IXGBE_VTEIMS value to mask. */
	intr->mask = IXGBE_VF_IRQ_ENABLE_MASK;

#endif //add by zs

}

static int
dwcvf_dev_configure(struct rte_eth_dev *dev)
{
	struct rte_eth_conf *conf = &dev->data->dev_conf;
	struct dwc_adapter *adapter =
			(struct dwc_adapter *)dev->data->dev_private;

	PMD_INIT_LOG(DEBUG, "Configured Virtual Function port id: %d",
		     dev->data->port_id);
	
	/*
	 * VF has no ability to enable/disable HW CRC
	 * Keep the persistent behavior the same as Host PF
	 */
#ifndef RTE_LIBRTE_IXGBE_PF_DISABLE_STRIP_CRC
	if (conf->rxmode.offloads & DEV_RX_OFFLOAD_KEEP_CRC) {
		PMD_INIT_LOG(NOTICE, "VF can't disable HW CRC Strip");
		conf->rxmode.offloads &= ~DEV_RX_OFFLOAD_KEEP_CRC;
	}
#else
	if (!(conf->rxmode.offloads & DEV_RX_OFFLOAD_KEEP_CRC)) {
		PMD_INIT_LOG(NOTICE, "VF can't enable HW CRC Strip");
		conf->rxmode.offloads |= DEV_RX_OFFLOAD_KEEP_CRC;
	}
#endif

	/*
	 * Initialize to TRUE. If any of Rx queues doesn't meet the bulk
	 * allocation or vector Rx preconditions we will reset it.
	 */
	adapter->rx_bulk_alloc_allowed = true;
	adapter->rx_vec_allowed = true;


	return 0;
}

static int
dwcvf_dev_start(struct rte_eth_dev *dev)
{
	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	uint32_t intr_vector = 0;
	struct rte_pci_device *pci_dev = RTE_ETH_DEV_TO_PCI(dev);
	struct rte_intr_handle *intr_handle = &pci_dev->intr_handle;

	int err, mask = 0;

	PMD_INIT_FUNC_TRACE();

	/* Stop the link setup handler before resetting the HW. */
	rte_eal_alarm_cancel(dwc_dev_setup_link_alarm_handler, dev);

	err = hw->mac.ops.reset_hw(hw);
	if (err) {
		PMD_INIT_LOG(ERR, "Unable to reset vf hardware (%d)", err);
		return err;
	}
	hw->mac.get_link_status = true;

#if 0 //add by zs

	/* negotiate mailbox API version to use with the PF. */
	ixgbevf_negotiate_api(hw);

	ixgbevf_dev_tx_init(dev);

	/* This can fail when allocating mbufs for descriptor rings */
	err = ixgbevf_dev_rx_init(dev);
	if (err) {
		PMD_INIT_LOG(ERR, "Unable to initialize RX hardware (%d)", err);
		dwc_dev_clear_queues(dev);
		return err;
	}

	/* Set vfta */
	ixgbevf_set_vfta_all(dev, 1);

	/* Set HW strip */
	mask = ETH_VLAN_STRIP_MASK | ETH_VLAN_FILTER_MASK |
		ETH_VLAN_EXTEND_MASK;
	err = ixgbevf_vlan_offload_config(dev, mask);
	if (err) {
		PMD_INIT_LOG(ERR, "Unable to set VLAN offload (%d)", err);
		dwc_dev_clear_queues(dev);
		return err;
	}

	ixgbevf_dev_rxtx_start(dev);

#endif //add by zs

	/* check and configure queue intr-vector mapping */
	if (rte_intr_cap_multiple(intr_handle) &&
	    dev->data->dev_conf.intr_conf.rxq) {
		/* According to datasheet, only vector 0/1/2 can be used,
		 * now only one vector is used for Rx queue
		 */
		intr_vector = 1;
		if (rte_intr_efd_enable(intr_handle, intr_vector))
			return -1;
	}

	if (rte_intr_dp_is_en(intr_handle) && !intr_handle->intr_vec) {
		intr_handle->intr_vec =
			rte_zmalloc("intr_vec",
				    dev->data->nb_rx_queues * sizeof(int), 0);
		if (intr_handle->intr_vec == NULL) {
			PMD_INIT_LOG(ERR, "Failed to allocate %d rx_queues"
				     " intr_vec", dev->data->nb_rx_queues);
			return -ENOMEM;
		}
	}
	dwcvf_configure_msix(dev);

	/* When a VF port is bound to VFIO-PCI, only miscellaneous interrupt
	 * is mapped to VFIO vector 0 in eth_dwcvf_dev_init( ).
	 * If previous VFIO interrupt mapping setting in eth_dwcvf_dev_init( )
	 * is not cleared, it will fail when following rte_intr_enable( ) tries
	 * to map Rx queue interrupt to other VFIO vectors.
	 * So clear uio/vfio intr/evevnfd first to avoid failure.
	 */
	rte_intr_disable(intr_handle);

	rte_intr_enable(intr_handle);

	/* Re-enable interrupt for VF */
	dwcvf_intr_enable(dev);

	/*
	 * Update link status right before return, because it may
	 * start link configuration process in a separate thread.
	 */
	dwcvf_dev_link_update(dev, 0);

	return 0;
}

static void
dwcvf_dev_stop(struct rte_eth_dev *dev)
{
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	struct rte_pci_device *pci_dev = RTE_ETH_DEV_TO_PCI(dev);
	struct rte_intr_handle *intr_handle = &pci_dev->intr_handle;

	PMD_INIT_FUNC_TRACE();

	rte_eal_alarm_cancel(dwc_dev_setup_link_alarm_handler, dev);

	dwcvf_intr_disable(dev);

	hw->adapter_stopped = 1;
	dwc_stop_adapter(hw);

#if 0 //add by zs

	/*
	  * Clear what we set, but we still keep shadow_vfta to
	  * restore after device starts
	  */
	ixgbevf_set_vfta_all(dev, 0);

#endif  //add by zs

	/* Clear stored conf */
	dev->data->scattered_rx = 0;

	dwc_dev_clear_queues(dev);

	/* Clean datapath event and queue/vec mapping */
	rte_intr_efd_disable(intr_handle);
	if (intr_handle->intr_vec != NULL) {
		rte_free(intr_handle->intr_vec);
		intr_handle->intr_vec = NULL;
	}
}

static void
dwcvf_dev_close(struct rte_eth_dev *dev)
{
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);

	PMD_INIT_FUNC_TRACE();

	dwc_reset_hw(hw);

	dwcvf_dev_stop(dev);

	dwc_dev_free_queues(dev);

	/**
	 * Remove the VF MAC address ro ensure
	 * that the VF traffic goes to the PF
	 * after stop, close and detach of the VF
	 **/
	dwcvf_remove_mac_addr(dev, 0);
}


static void
dwcvf_configure_msix(struct rte_eth_dev *dev)
{
	struct rte_pci_device *pci_dev = RTE_ETH_DEV_TO_PCI(dev);
	struct rte_intr_handle *intr_handle = &pci_dev->intr_handle;
	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	uint32_t q_idx;
	uint32_t vector_idx = DWC_MISC_VEC_ID;
	uint32_t base = DWC_MISC_VEC_ID;

#if 0 //add by zs

	/* Configure VF other cause ivar */
	ixgbevf_set_ivar_map(hw, -1, 1, vector_idx);

	/* won't configure msix register if no mapping is done
	 * between intr vector and event fd.
	 */
	if (!rte_intr_dp_is_en(intr_handle))
		return;

	if (rte_intr_allow_others(intr_handle)) {
		base = IXGBE_RX_VEC_START;
		vector_idx = IXGBE_RX_VEC_START;
	}

	/* Configure all RX queues of VF */
	for (q_idx = 0; q_idx < dev->data->nb_rx_queues; q_idx++) {
		/* Force all queue use vector 0,
		 * as IXGBE_VF_MAXMSIVECOTR = 1
		 */
		ixgbevf_set_ivar_map(hw, 0, q_idx, vector_idx);
		intr_handle->intr_vec[q_idx] = vector_idx;
		if (vector_idx < base + intr_handle->nb_efd - 1)
			vector_idx++;
	}

	/* As RX queue setting above show, all queues use the vector 0.
	 * Set only the ITR value of DWC_MISC_VEC_ID.
	 */
	DWC_WRITE_REG(hw, IXGBE_VTEITR(DWC_MISC_VEC_ID),
			IXGBE_EITR_INTERVAL_US(IXGBE_QUEUE_ITR_INTERVAL_DEFAULT)
			| IXGBE_EITR_CNT_WDIS);

#endif //add by zs

}

/**
 * Sets up the hardware to properly generate MSI-X interrupts
 * @hw
 *  board private structure
 */
static void
dwc_configure_msix(struct rte_eth_dev *dev)
{
	struct rte_pci_device *pci_dev = RTE_ETH_DEV_TO_PCI(dev);
	struct rte_intr_handle *intr_handle = &pci_dev->intr_handle;
	struct dwc_hw *hw =
		DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	uint32_t queue_id, base = DWC_MISC_VEC_ID;
	uint32_t vec = DWC_MISC_VEC_ID;
	uint32_t mask;
	uint32_t gpie;

#if 0 //add by zs

	/* won't configure msix register if no mapping is done
	 * between intr vector and event fd
	 * but if misx has been enabled already, need to configure
	 * auto clean, auto mask and throttling.
	 */
	gpie = DWC_READ_REG(hw, IXGBE_GPIE);
	if (!rte_intr_dp_is_en(intr_handle) &&
	    !(gpie & (IXGBE_GPIE_MSIX_MODE | IXGBE_GPIE_PBA_SUPPORT)))
		return;

	if (rte_intr_allow_others(intr_handle))
		vec = base = IXGBE_RX_VEC_START;

	/* setup GPIE for MSI-x mode */
	gpie = DWC_READ_REG(hw, IXGBE_GPIE);
	gpie |= IXGBE_GPIE_MSIX_MODE | IXGBE_GPIE_PBA_SUPPORT |
		IXGBE_GPIE_OCD | IXGBE_GPIE_EIAME;
	/* auto clearing and auto setting corresponding bits in EIMS
	 * when MSI-X interrupt is triggered
	 */
	if (hw->mac.type == dwc_mac_1) {
		DWC_WRITE_REG(hw, IXGBE_EIAM, IXGBE_EICS_RTX_QUEUE);
	} else {
		DWC_WRITE_REG(hw, IXGBE_EIAM_EX(0), 0xFFFFFFFF);
		DWC_WRITE_REG(hw, IXGBE_EIAM_EX(1), 0xFFFFFFFF);
	}
	DWC_WRITE_REG(hw, IXGBE_GPIE, gpie);

	/* Populate the IVAR table and set the ITR values to the
	 * corresponding register.
	 */
	if (rte_intr_dp_is_en(intr_handle)) {
		for (queue_id = 0; queue_id < dev->data->nb_rx_queues;
			queue_id++) {
			/* by default, 1:1 mapping */
			ixgbe_set_ivar_map(hw, 0, queue_id, vec);
			intr_handle->intr_vec[queue_id] = vec;
			if (vec < base + intr_handle->nb_efd - 1)
				vec++;
		}

		switch (hw->mac.type) {
		case dwc_mac_1:
			ixgbe_set_ivar_map(hw, -1,
					   IXGBE_IVAR_OTHER_CAUSES_INDEX,
					   DWC_MISC_VEC_ID);
			break;
		case ixgbe_mac_82599EB:
		case ixgbe_mac_X540:
		case ixgbe_mac_X550:
			ixgbe_set_ivar_map(hw, -1, 1, DWC_MISC_VEC_ID);
			break;
		default:
			break;
		}
	}
	DWC_WRITE_REG(hw, IXGBE_EITR(DWC_MISC_VEC_ID),
			IXGBE_EITR_INTERVAL_US(IXGBE_QUEUE_ITR_INTERVAL_DEFAULT)
			| IXGBE_EITR_CNT_WDIS);

	/* set up to autoclear timer, and the vectors */
	mask = IXGBE_EIMS_ENABLE_MASK;
	mask &= ~(IXGBE_EIMS_OTHER |
		  IXGBE_EIMS_MAILBOX |
		  IXGBE_EIMS_LSC);

	DWC_WRITE_REG(hw, IXGBE_EIAC, mask);

#endif //add by zs

}


static void
dwcvf_remove_mac_addr(struct rte_eth_dev *dev, uint32_t index)
{
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	struct ether_addr *perm_addr = (struct ether_addr *) hw->mac.perm_addr;
	struct ether_addr *mac_addr;
	uint32_t i;
	int diag;

	/*
	 * The IXGBE_VF_SET_MACVLAN command of the ixgbe-pf driver does
	 * not support the deletion of a given MAC address.
	 * Instead, it imposes to delete all MAC addresses, then to add again
	 * all MAC addresses with the exception of the one to be deleted.
	 */
	(void) ixgbevf_set_uc_addr_vf(hw, 0, NULL);

	/*
	 * Add again all MAC addresses, with the exception of the deleted one
	 * and of the permanent MAC address.
	 */
	for (i = 0, mac_addr = dev->data->mac_addrs;
	     i < hw->mac.num_rar_entries; i++, mac_addr++) {
		/* Skip the deleted MAC address */
		if (i == index)
			continue;
		/* Skip NULL MAC addresses */
		if (is_zero_ether_addr(mac_addr))
			continue;
		/* Skip the permanent MAC address */
		if (memcmp(perm_addr, mac_addr, sizeof(struct ether_addr)) == 0)
			continue;
		diag = ixgbevf_set_uc_addr_vf(hw, 2, mac_addr->addr_bytes);
		if (diag != 0)
			PMD_DRV_LOG(ERR,
				    "Adding again MAC address "
				    "%02x:%02x:%02x:%02x:%02x:%02x failed "
				    "diag=%d",
				    mac_addr->addr_bytes[0],
				    mac_addr->addr_bytes[1],
				    mac_addr->addr_bytes[2],
				    mac_addr->addr_bytes[3],
				    mac_addr->addr_bytes[4],
				    mac_addr->addr_bytes[5],
				    diag);
	}
}


static inline enum ixgbe_5tuple_protocol
convert_protocol_type(uint8_t protocol_value)
{
	if (protocol_value == IPPROTO_TCP)
		return IXGBE_FILTER_PROTOCOL_TCP;
	else if (protocol_value == IPPROTO_UDP)
		return IXGBE_FILTER_PROTOCOL_UDP;
	else if (protocol_value == IPPROTO_SCTP)
		return IXGBE_FILTER_PROTOCOL_SCTP;
	else
		return IXGBE_FILTER_PROTOCOL_NONE;
}

uint16_t
dwc_reta_size_get(enum ixgbe_mac_type mac_type) {
	switch (mac_type) {
	case dwc_mac_1:
		return ETH_RSS_RETA_SIZE_512;
	default:
		return ETH_RSS_RETA_SIZE_128;
	}
}


#if 0 //add by zs

/* Update e-tag ether type */
static int
dwc_update_e_tag_eth_type(struct dwc_hw *hw,
			    uint16_t ether_type)
{
	uint32_t etag_etype;

	if (hw->mac.type != ixgbe_mac_X550 &&
	    hw->mac.type != ixgbe_mac_X550EM_x &&
	    hw->mac.type != ixgbe_mac_X550EM_a) {
		return -ENOTSUP;
	}

	etag_etype = DWC_READ_REG(hw, IXGBE_ETAG_ETYPE);
	etag_etype &= ~IXGBE_ETAG_ETYPE_MASK;
	etag_etype |= ether_type;
	DWC_WRITE_REG(hw, IXGBE_ETAG_ETYPE, etag_etype);
	DWC_WRITE_FLUSH(hw);

	return 0;
}

/* Enable e-tag tunnel */
static int
dwc_e_tag_enable(struct dwc_hw *hw)
{
	uint32_t etag_etype;

	if (hw->mac.type != ixgbe_mac_X550 &&
	    hw->mac.type != ixgbe_mac_X550EM_x &&
	    hw->mac.type != ixgbe_mac_X550EM_a) {
		return -ENOTSUP;
	}

	etag_etype = DWC_READ_REG(hw, IXGBE_ETAG_ETYPE);
	etag_etype |= IXGBE_ETAG_ETYPE_VALID;
	DWC_WRITE_REG(hw, IXGBE_ETAG_ETYPE, etag_etype);
	DWC_WRITE_FLUSH(hw);


	return 0;
}

static int
dwc_e_tag_forwarding_en_dis(struct rte_eth_dev *dev, bool en)
{
	int ret = 0;
	uint32_t ctrl;
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);

	if (hw->mac.type != ixgbe_mac_X550 &&
	    hw->mac.type != ixgbe_mac_X550EM_x &&
	    hw->mac.type != ixgbe_mac_X550EM_a) {
		return -ENOTSUP;
	}

	ctrl = DWC_READ_REG(hw, IXGBE_VT_CTL);
	ctrl &= ~IXGBE_VT_CTL_POOLING_MODE_MASK;
	if (en)
		ctrl |= IXGBE_VT_CTL_POOLING_MODE_ETAG;
	DWC_WRITE_REG(hw, IXGBE_VT_CTL, ctrl);

	return ret;
}

#endif //add by zs

static int
dwcvf_dev_interrupt_get_status(struct rte_eth_dev *dev)
{
	uint32_t eicr;
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);
	struct ixgbe_interrupt *intr =
		DWC_DEV_PRIVATE_TO_INTR(dev->data->dev_private);
	dwcvf_intr_disable(dev);

	/* read-on-clear nic registers here */
	eicr = DWC_READ_REG(hw, IXGBE_VTEICR);
	intr->flags = 0;

	/* only one misc vector supported - mailbox */
	eicr &= DWC_VTEICR_MASK;
	if (eicr == DWC_MISC_VEC_ID)
		intr->flags |= DWC_FLAG_MAILBOX;

	return 0;
}

static int
dwcvf_dev_interrupt_action(struct rte_eth_dev *dev)
{
	struct dwc_interrupt *intr =
		DWC_DEV_PRIVATE_TO_INTR(dev->data->dev_private);

#if 0 //add by zs

	if (intr->flags & DWC_FLAG_MAILBOX) {
		ixgbevf_mbx_process(dev);
		intr->flags &= ~DWC_FLAG_MAILBOX;
	}

	dwcvf_intr_enable(dev);

#endif //add by zs

	return 0;
}

static void
dwcvf_dev_interrupt_handler(void *param)
{
	struct rte_eth_dev *dev = (struct rte_eth_dev *)param;

	dwcvf_dev_interrupt_get_status(dev);
	dwcvf_dev_interrupt_action(dev);
}

#if  0	//add by zs, 20200224

static int
dwc_filter_restore(struct rte_eth_dev *dev)
{

	ixgbe_ntuple_filter_restore(dev);
	ixgbe_ethertype_filter_restore(dev);
	ixgbe_syn_filter_restore(dev);
	ixgbe_fdir_filter_restore(dev);
	ixgbe_l2_tn_filter_restore(dev);
	ixgbe_rss_filter_restore(dev);

	return 0;
}

static void
dwc_l2_tunnel_conf(struct rte_eth_dev *dev)
{
	struct dwc_l2_tn_info *l2_tn_info =
		DWC_DEV_PRIVATE_TO_L2_TN_INFO(dev->data->dev_private);
	struct dwc_hw *hw = DWC_DEV_PRIVATE_TO_HW(dev->data->dev_private);

	if (l2_tn_info->e_tag_en)
		(void)dwc_e_tag_enable(hw);

	if (l2_tn_info->e_tag_fwd_en)
		(void)dwc_e_tag_forwarding_en_dis(dev, 1);

	(void)dwc_update_e_tag_eth_type(hw, l2_tn_info->e_tag_ether_type);
}

#endif  //end add by zs, 20200224


RTE_PMD_REGISTER_PCI(net_dwc, rte_dwc_pmd);
RTE_PMD_REGISTER_PCI_TABLE(net_dwc, pci_id_dwc_map);
RTE_PMD_REGISTER_KMOD_DEP(net_dwc, "* igb_uio | uio_pci_generic | vfio-pci");
//RTE_PMD_REGISTER_PCI(net_ixgbe_vf, rte_dwcvf_pmd);
//RTE_PMD_REGISTER_PCI_TABLE(net_ixgbe_vf, pci_id_dwcvf_map);
//RTE_PMD_REGISTER_KMOD_DEP(net_ixgbe_vf, "* igb_uio | vfio-pci");

RTE_INIT(dwc_init_log)
{
	dwc_logtype_init = rte_log_register("pmd.net.dwc.init");
	if (dwc_logtype_init >= 0)
		rte_log_set_level(dwc_logtype_init, RTE_LOG_NOTICE);
	dwc_logtype_driver = rte_log_register("pmd.net.dwc.driver");
	if (dwc_logtype_driver >= 0)
		rte_log_set_level(dwc_logtype_driver, RTE_LOG_NOTICE);
}
