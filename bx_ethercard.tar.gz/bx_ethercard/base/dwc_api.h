/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2001-2018
 */

#ifndef _DWC_API_H_
#define _DWC_API_H_

#include "dwc_type.h"

s32 dwc_stop_adapter(struct dwc_hw *hw);
s32 dwc_init_shared_code(struct dwc_hw *hw);
s32 dwc_set_mac_type(struct dwc_hw *hw);
s32 dwc_init_hw(struct dwc_hw *hw);
s32 dwc_reset_hw(struct dwc_hw *hw);
s32 dwc_get_bus_info(struct dwc_hw *hw);
u32 dwc_get_num_of_tx_queues(struct dwc_hw *hw);
u32 dwc_get_num_of_rx_queues(struct dwc_hw *hw);
s32 dwc_identify_phy(struct dwc_hw *hw);
extern s32 dwc_init_ops(struct dwc_hw *hw);

s32 dwc_set_mac_type(struct dwc_hw *hw);
s32 dwc_init_hw(struct dwc_hw *hw);
s32 dwc_reset_hw(struct dwc_hw *hw);
s32 dwc_start_hw(struct dwc_hw *hw);
void dwc_enable_relaxed_ordering(struct dwc_hw *hw);
s32 dwc_clear_hw_cntrs(struct dwc_hw *hw);
enum dwc_media_type dwc_get_media_type(struct dwc_hw *hw);
s32 dwc_get_mac_addr(struct dwc_hw *hw, u8 *mac_addr);
s32 dwc_get_bus_info(struct dwc_hw *hw);
u32 dwc_get_num_of_tx_queues(struct dwc_hw *hw);
u32 dwc_get_num_of_rx_queues(struct dwc_hw *hw);
s32 dwc_stop_adapter(struct dwc_hw *hw);
s32 dwc_read_pba_num(struct dwc_hw *hw, u32 *pba_num);
s32 dwc_read_pba_string(struct dwc_hw *hw, u8 *pba_num, u32 pba_num_size);

s32 dwc_identify_phy(struct dwc_hw *hw);
s32 dwc_reset_phy(struct dwc_hw *hw);
s32 dwc_read_phy_reg(struct dwc_hw *hw, u32 reg_addr, u32 device_type,
		       u16 *phy_data);
s32 dwc_write_phy_reg(struct dwc_hw *hw, u32 reg_addr, u32 device_type,
			u16 phy_data);

s32 dwc_setup_phy_link(struct dwc_hw *hw);
s32 dwc_setup_internal_phy(struct dwc_hw *hw);
s32 dwc_check_phy_link(struct dwc_hw *hw,
			 dwc_link_speed *speed,
			 bool *link_up);
s32 dwc_setup_phy_link_speed(struct dwc_hw *hw,
			       dwc_link_speed speed,
			       bool autoneg_wait_to_complete);
s32 dwc_set_phy_power(struct dwc_hw *, bool on);
void dwc_disable_tx_laser(struct dwc_hw *hw);
void dwc_enable_tx_laser(struct dwc_hw *hw);
void dwc_flap_tx_laser(struct dwc_hw *hw);
s32 dwc_setup_link(struct dwc_hw *hw, dwc_link_speed speed,
		     bool autoneg_wait_to_complete);
s32 dwc_setup_mac_link(struct dwc_hw *hw, dwc_link_speed speed,
			 bool autoneg_wait_to_complete);
s32 dwc_check_link(struct dwc_hw *hw, dwc_link_speed *speed,
		     bool *link_up, bool link_up_wait_to_complete);
s32 dwc_get_link_capabilities(struct dwc_hw *hw, dwc_link_speed *speed,
				bool *autoneg);
s32 dwc_led_on(struct dwc_hw *hw, u32 index);
s32 dwc_led_off(struct dwc_hw *hw, u32 index);
s32 dwc_blink_led_start(struct dwc_hw *hw, u32 index);
s32 dwc_blink_led_stop(struct dwc_hw *hw, u32 index);

s32 dwc_init_eeprom_params(struct dwc_hw *hw);
s32 dwc_write_eeprom(struct dwc_hw *hw, u16 offset, u16 data);
s32 dwc_write_eeprom_buffer(struct dwc_hw *hw, u16 offset,
			      u16 words, u16 *data);
s32 dwc_read_eeprom(struct dwc_hw *hw, u16 offset, u16 *data);
s32 dwc_read_eeprom_buffer(struct dwc_hw *hw, u16 offset,
			     u16 words, u16 *data);

s32 dwc_validate_eeprom_checksum(struct dwc_hw *hw, u16 *checksum_val);
s32 dwc_update_eeprom_checksum(struct dwc_hw *hw);

s32 dwc_insert_mac_addr(struct dwc_hw *hw, u8 *addr, u32 vmdq);
s32 dwc_set_rar(struct dwc_hw *hw, u32 index, u8 *addr, u32 vmdq,
		  u32 enable_addr);
s32 dwc_clear_rar(struct dwc_hw *hw, u32 index);
s32 dwc_set_vmdq(struct dwc_hw *hw, u32 rar, u32 vmdq);
s32 dwc_set_vmdq_san_mac(struct dwc_hw *hw, u32 vmdq);
s32 dwc_clear_vmdq(struct dwc_hw *hw, u32 rar, u32 vmdq);
s32 dwc_init_rx_addrs(struct dwc_hw *hw);
u32 dwc_get_num_rx_addrs(struct dwc_hw *hw);

void dwc_add_uc_addr(struct dwc_hw *hw, u8 *addr_list, u32 vmdq);
s32 dwc_enable_mc(struct dwc_hw *hw);
s32 dwc_disable_mc(struct dwc_hw *hw);
s32 dwc_clear_vfta(struct dwc_hw *hw);
s32 dwc_set_vfta(struct dwc_hw *hw, u32 vlan,
		   u32 vind, bool vlan_on, bool vlvf_bypass);
s32 dwc_set_vlvf(struct dwc_hw *hw, u32 vlan, u32 vind,
		   bool vlan_on, u32 *vfta_delta, u32 vfta,
		   bool vlvf_bypass);
s32 dwc_fc_enable(struct dwc_hw *hw);
s32 dwc_setup_fc(struct dwc_hw *hw);
s32 dwc_set_fw_drv_ver(struct dwc_hw *hw, u8 maj, u8 min, u8 build,
			 u8 ver, u16 len, char *driver_ver);
s32 dwc_get_thermal_sensor_data(struct dwc_hw *hw);
s32 dwc_init_thermal_sensor_thresh(struct dwc_hw *hw);
void dwc_set_mta(struct dwc_hw *hw, u8 *mc_addr);
s32 dwc_get_phy_firmware_version(struct dwc_hw *hw,
				   u16 *firmware_version);
s32 dwc_read_analog_reg8(struct dwc_hw *hw, u32 reg, u8 *val);
s32 dwc_write_analog_reg8(struct dwc_hw *hw, u32 reg, u8 val);
s32 dwc_init_uta_tables(struct dwc_hw *hw);
s32 dwc_read_i2c_eeprom(struct dwc_hw *hw, u8 byte_offset, u8 *eeprom_data);
u64 dwc_get_supported_physical_layer(struct dwc_hw *hw);
s32 dwc_enable_rx_dma(struct dwc_hw *hw, u32 regval);
s32 dwc_disable_sec_rx_path(struct dwc_hw *hw);
s32 dwc_enable_sec_rx_path(struct dwc_hw *hw);
s32 dwc_mng_fw_enabled(struct dwc_hw *hw);
s32 dwc_read_i2c_byte(struct dwc_hw *hw, u8 byte_offset, u8 dev_addr,
			u8 *data);
s32 dwc_read_i2c_byte_unlocked(struct dwc_hw *hw, u8 byte_offset,
				 u8 dev_addr, u8 *data);
s32 dwc_read_link(struct dwc_hw *hw, u8 addr, u16 reg, u16 *val);
s32 dwc_read_link_unlocked(struct dwc_hw *hw, u8 addr, u16 reg, u16 *val);
s32 dwc_write_i2c_byte(struct dwc_hw *hw, u8 byte_offset, u8 dev_addr,
			 u8 data);
s32 dwc_write_i2c_byte_unlocked(struct dwc_hw *hw, u8 byte_offset,
				  u8 dev_addr, u8 data);
s32 dwc_write_link(struct dwc_hw *hw, u8 addr, u16 reg, u16 val);
s32 dwc_write_link_unlocked(struct dwc_hw *hw, u8 addr, u16 reg, u16 val);
s32 dwc_write_i2c_eeprom(struct dwc_hw *hw, u8 byte_offset, u8 eeprom_data);
s32 dwc_get_san_mac_addr(struct dwc_hw *hw, u8 *san_mac_addr);
s32 dwc_set_san_mac_addr(struct dwc_hw *hw, u8 *san_mac_addr);
s32 dwc_get_device_caps(struct dwc_hw *hw, u16 *device_caps);
s32 dwc_acquire_swfw_semaphore(struct dwc_hw *hw, u32 mask);
void dwc_release_swfw_semaphore(struct dwc_hw *hw, u32 mask);
void dwc_init_swfw_semaphore(struct dwc_hw *hw);
s32 dwc_get_wwn_prefix(struct dwc_hw *hw, u16 *wwnn_prefix,
			 u16 *wwpn_prefix);
s32 dwc_get_fcoe_boot_status(struct dwc_hw *hw, u16 *bs);
s32 dwc_dmac_config(struct dwc_hw *hw);
s32 dwc_dmac_update_tcs(struct dwc_hw *hw);
s32 dwc_dmac_config_tcs(struct dwc_hw *hw);
s32 dwc_setup_eee(struct dwc_hw *hw, bool enable_eee);
void dwc_set_source_address_pruning(struct dwc_hw *hw, bool enable,
				      unsigned int vf);
void dwc_set_ethertype_anti_spoofing(struct dwc_hw *hw, bool enable,
				       int vf);
s32 dwc_read_iosf_sb_reg(struct dwc_hw *hw, u32 reg_addr,
			u32 device_type, u32 *phy_data);
s32 dwc_write_iosf_sb_reg(struct dwc_hw *hw, u32 reg_addr,
			u32 device_type, u32 phy_data);
void dwc_disable_mdd(struct dwc_hw *hw);
void dwc_enable_mdd(struct dwc_hw *hw);
void dwc_mdd_event(struct dwc_hw *hw, u32 *vf_bitmap);
void dwc_restore_mdd_vf(struct dwc_hw *hw, u32 vf);
bool dwc_fw_recovery_mode(struct dwc_hw *hw);
s32 dwc_enter_lplu(struct dwc_hw *hw);
s32 dwc_handle_lasi(struct dwc_hw *hw);
void dwc_set_rate_select_speed(struct dwc_hw *hw, dwc_link_speed speed);
void dwc_disable_rx(struct dwc_hw *hw);
void dwc_enable_rx(struct dwc_hw *hw);
s32 dwc_negotiate_fc(struct dwc_hw *hw, u32 adv_reg, u32 lp_reg,
			u32 adv_sym, u32 adv_asm, u32 lp_sym, u32 lp_asm);


#endif /* _DWC_API_H_ */
